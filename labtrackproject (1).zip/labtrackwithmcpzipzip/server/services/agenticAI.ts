import OpenAI from "openai";

// Use GPT-4o-mini - works with all OpenAI API keys
let openaiInstance: OpenAI | null = null;
const API_KEY = process.env["OPENAI_API_KEY"];

console.log("API Key Loaded:", !!API_KEY);
function getOpenAI(): OpenAI {
  if (!openaiInstance) {
    if (!API_KEY) {
      throw new Error("OpenAI API key not configured");
    }
    openaiInstance = new OpenAI({
      apiKey: API_KEY,
      timeout: 30000,
    });
  }
  return openaiInstance;
}

export interface MCPProjectInput {
  id?: string;
  title?: string;
  description?: string;
  estimated_cost: number;
  estimated_time_needed: string;
  required_team: string[];
  required_resources: string[];
  complexity_level: string;
  submittedAt?: string;
}

export interface AIRecommendation {
  team_allocation: {
    role: string;
    assigned_member?: string;
    lab_assignment?: string;
    availability_status: string;
    allocation_reasoning: string;
  }[];
  resource_allocation: {
    resource: string;
    assigned_lab?: string;
    quantity_needed: number;
    availability_status: string;
    alternative_suggestion?: string;
    allocation_reasoning: string;
  }[];
  timeline_adjustments: {
    original_timeline: string;
    recommended_timeline: string;
    adjustment_reason: string;
    milestones: {
      phase: string;
      duration: string;
      description: string;
    }[];
  };
  budget_optimization: {
    original_cost: number;
    optimized_cost: number;
    savings_percentage: number;
    optimization_tips: string[];
  };
  risk_assessment: {
    risk_level: string;
    identified_risks: string[];
    mitigation_strategies: string[];
  };
  overall_recommendations: string[];
  confidence_score: number;
}

export interface ProcessedMCPProject {
  id: string;
  originalInput: MCPProjectInput;
  aiRecommendations: AIRecommendation;
  processedAt: string;
  status:
    | "pending"
    | "processing"
    | "completed"
    | "failed"
    | "resource_shortage"
    | "expired";
  error?: string;
  hasResourceShortage?: boolean;
}

// ✅ SIMPLE CONFIGURATION - GPT-4o-mini works with all OpenAI keys
const CONFIG = {
  AI_MODELS: ["gpt-4o-mini"], // Changed from gpt-5-nano
  AI_TIMEOUT: 30000,
  AI_MAX_TOKENS: 2000,
  MAX_RETRIES: 2,
  RETRY_DELAY_BASE_MS: 1000,
};

// Simple input validation
function validateInputs(
  projectInput: MCPProjectInput,
  availableLabs: any[],
  availableResources: any[],
  availableUsers: any[],
): void {
  if (!projectInput || typeof projectInput !== "object") {
    throw new Error("Invalid project input");
  }
  if (!projectInput.required_team || !projectInput.required_resources) {
    throw new Error("Missing required fields");
  }
}

// Fallback recommendations
export function generateFallbackRecommendations(
  projectInput: MCPProjectInput,
  availableLabs: any[],
  availableResources: any[],
  availableUsers: any[],
): AIRecommendation {
  const teamAllocation = projectInput.required_team.map((role) => ({
    role,
    assigned_member: availableUsers.find((u) =>
      u.role.toLowerCase().includes(role.toLowerCase().split(" ")[0]),
    )?.name,
    lab_assignment: availableLabs[0]?.labName,
    availability_status: "available",
    allocation_reasoning: "Fallback assignment",
  }));

  const resourceAllocation = projectInput.required_resources.map(
    (resource) => ({
      resource,
      assigned_lab: availableLabs[0]?.labName,
      quantity_needed: 1,
      availability_status: "available",
      alternative_suggestion: null,
      allocation_reasoning: "Fallback assignment",
    }),
  );

  return {
    team_allocation: teamAllocation,
    resource_allocation: resourceAllocation,
    timeline_adjustments: {
      original_timeline: projectInput.estimated_time_needed,
      recommended_timeline: projectInput.estimated_time_needed,
      adjustment_reason: "Fallback mode",
      milestones: [
        {
          phase: "Setup",
          duration: "2 weeks",
          description: "Initial preparation",
        },
        {
          phase: "Execution",
          duration: projectInput.estimated_time_needed,
          description: "Main work",
        },
      ],
    },
    budget_optimization: {
      original_cost: projectInput.estimated_cost,
      optimized_cost: Math.round(projectInput.estimated_cost * 0.9),
      savings_percentage: 10,
      optimization_tips: ["Review allocations manually"],
    },
    risk_assessment: {
      risk_level: "medium",
      identified_risks: ["Fallback mode active"],
      mitigation_strategies: ["Manual review required"],
    },
    overall_recommendations: ["Please review allocations manually"],
    confidence_score: 0,
  };
}

// ✅ MAIN FUNCTION - Simple and working
export async function analyzeProjectWithAI(
  projectInput: MCPProjectInput,
  availableLabs: any[],
  availableResources: any[],
  availableUsers: any[],
): Promise<AIRecommendation> {
  console.log("Starting AI analysis with GPT-4o-mini...");
  const startTime = Date.now();

  try {
    validateInputs(
      projectInput,
      availableLabs,
      availableResources,
      availableUsers,
    );
  } catch (error: any) {
    console.error("Validation error:", error.message);
    return generateFallbackRecommendations(
      projectInput,
      availableLabs,
      availableResources,
      availableUsers,
    );
  }

  // Prepare the prompt
  // In your analyzeProjectWithAI function, update the system prompt:
  const systemPrompt = `You are an Agentic AI assistant specialized in lab resource management. Your role is to analyze incoming project requirements and provide optimal resource allocation recommendations.

  CRITICAL REQUIREMENTS:
  1. You MUST include ALL required resources listed by the user
  2. Budget numbers MUST be realistic (thousands or millions, not hundreds)
  3. Use lowercase for availability_status: "available", "partial", or "unavailable"
  4. Match resources from available inventory when possible
  5. Calculate realistic cost savings (5-20% typically)

  Respond ONLY with valid JSON matching this exact structure (no additional text):
  {
    "team_allocation": [{ "role": string, "assigned_member": string | null, "lab_assignment": string | null, "availability_status": "available" | "partial" | "unavailable", "allocation_reasoning": string }],
    "resource_allocation": [{ "resource": string, "assigned_lab": string | null, "quantity_needed": number, "availability_status": "available" | "partial" | "unavailable", "alternative_suggestion": string | null, "allocation_reasoning": string }],
    "timeline_adjustments": { "original_timeline": string, "recommended_timeline": string, "adjustment_reason": string, "milestones": [{ "phase": string, "duration": string, "description": string }] },
    "budget_optimization": { "original_cost": number, "optimized_cost": number, "savings_percentage": number, "optimization_tips": string[] },
    "risk_assessment": { "risk_level": "low" | "medium" | "high", "identified_risks": string[], "mitigation_strategies": string[] },
    "overall_recommendations": string[],
    "confidence_score": number (0-100)
  }`;

  const userPrompt = `Create resource allocation recommendations for this project:

PROJECT:
${projectInput.title ? `Title: ${projectInput.title}` : ""}
${projectInput.description ? `Description: ${projectInput.description}` : ""}
Estimated Cost: $${projectInput.estimated_cost}
Timeline: ${projectInput.estimated_time_needed}
Complexity: ${projectInput.complexity_level}

Required Team Roles: ${projectInput.required_team.join(", ")}
Required Resources: ${projectInput.required_resources.join(", ")}

Available Labs: ${JSON.stringify(availableLabs.map((l) => ({ name: l.labName, capacity: l.labCapacity })))}
Available Team: ${JSON.stringify(availableUsers.map((u) => ({ name: u.name, role: u.role })))}
Available Resources: ${JSON.stringify(availableResources.map((r) => ({ name: r.name, quantity: r.quantity, status: r.status })))}

Return JSON with these exact fields:
- team_allocation: array of {role, assigned_member, lab_assignment, availability_status, allocation_reasoning}
- resource_allocation: array of {resource, assigned_lab, quantity_needed, availability_status, alternative_suggestion, allocation_reasoning}
- timeline_adjustments: {original_timeline, recommended_timeline, adjustment_reason, milestones: array of {phase, duration, description}}
- budget_optimization: {original_cost, optimized_cost, savings_percentage, optimization_tips}
- risk_assessment: {risk_level, identified_risks, mitigation_strategies}
- overall_recommendations: array of strings
- confidence_score: number 0-100`;

  try {
    const openai = getOpenAI();

    // ✅ Use Chat Completions API with gpt-4o-mini
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini", // ✅ This works!
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" }, // Force JSON
      max_tokens: CONFIG.AI_MAX_TOKENS,
      temperature: 0.3, // Lower temp for more consistent JSON
    });

    const content = response.choices[0]?.message?.content;

    if (!content) {
      throw new Error("No response from AI");
    }
    console.log("Raw AI Response:", content);
    console.log("AI Response received, length:", content.length);

    // Parse JSON
    const recommendations = JSON.parse(content) as AIRecommendation;

    // Quick validation
    if (
      !recommendations.team_allocation ||
      !recommendations.resource_allocation
    ) {
      throw new Error("Invalid response structure");
    }

    const duration = Date.now() - startTime;
    console.log(`✅ AI analysis successful in ${duration}ms`);

    return recommendations;
  } catch (error: any) {
    console.error("AI analysis failed:", error.message);

    // Log more details if available
    if (error.status) console.error("Status:", error.status);
    if (error.code) console.error("Code:", error.code);

    const duration = Date.now() - startTime;
    console.log(`Using fallback after ${duration}ms`);

    return generateFallbackRecommendations(
      projectInput,
      availableLabs,
      availableResources,
      availableUsers,
    );
  }
}

// ✅ TEST FUNCTION - Verify everything works
export async function testAIConnection() {
  console.log("\n=== Testing AI Connection ===");

  try {
    const openai = getOpenAI();

    // Simple test query
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: "Say 'AI is working!'" }],
      max_tokens: 20,
    });

    const result = response.choices[0]?.message?.content;
    console.log(`✅ SUCCESS: ${result}`);
    console.log("Your OpenAI API key is working correctly with gpt-4o-mini!");
    return true;
  } catch (error: any) {
    console.error("❌ FAILED:", error.message);

    if (error.code === "invalid_api_key") {
      console.error(
        "Your API key is invalid. Check your SPM_Project_KEY environment variable.",
      );
    } else if (error.code === "insufficient_quota") {
      console.error(
        "Your account has no credits. Add funds at platform.openai.com",
      );
    } else {
      console.error("Error details:", error);
    }

    return false;
  }
}

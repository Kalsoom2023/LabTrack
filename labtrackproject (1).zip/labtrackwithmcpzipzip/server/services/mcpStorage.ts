import * as fs from "fs";
import * as path from "path";
import { MCPProjectInput, ProcessedMCPProject, AIRecommendation } from "./agenticAI";

const DATA_DIR = path.join(process.cwd(), "LabTrack2", "data");
const MCP_PROJECTS_FILE = path.join(DATA_DIR, "mcp-projects.json");

function ensureDataDirectory(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadProjects(): ProcessedMCPProject[] {
  ensureDataDirectory();
  try {
    if (fs.existsSync(MCP_PROJECTS_FILE)) {
      const data = fs.readFileSync(MCP_PROJECTS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error loading MCP projects:", error);
  }
  return [];
}

function saveProjects(projects: ProcessedMCPProject[]): void {
  ensureDataDirectory();
  try {
    fs.writeFileSync(MCP_PROJECTS_FILE, JSON.stringify(projects, null, 2));
  } catch (error) {
    console.error("Error saving MCP projects:", error);
    throw error;
  }
}

export function generateProjectId(): string {
  return `mcp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function getAllMCPProjects(): ProcessedMCPProject[] {
  return loadProjects();
}

export function getMCPProjectById(id: string): ProcessedMCPProject | null {
  const projects = loadProjects();
  return projects.find(p => p.id === id) || null;
}

export function createMCPProject(input: MCPProjectInput): ProcessedMCPProject {
  const projects = loadProjects();
  
  const newProject: ProcessedMCPProject = {
    id: input.id || generateProjectId(),
    originalInput: {
      ...input,
      submittedAt: new Date().toISOString()
    },
    aiRecommendations: null as any,
    processedAt: "",
    status: "pending"
  };
  
  projects.push(newProject);
  saveProjects(projects);
  
  return newProject;
}

export function updateMCPProjectWithRecommendations(
  id: string, 
  recommendations: AIRecommendation
): ProcessedMCPProject | null {
  const projects = loadProjects();
  const projectIndex = projects.findIndex(p => p.id === id);
  
  if (projectIndex === -1) {
    return null;
  }
  
  projects[projectIndex] = {
    ...projects[projectIndex],
    aiRecommendations: recommendations,
    processedAt: new Date().toISOString(),
    status: "completed"
  };
  
  saveProjects(projects);
  return projects[projectIndex];
}

export function updateMCPProjectStatus(
  id: string, 
  status: ProcessedMCPProject["status"],
  error?: string
): ProcessedMCPProject | null {
  const projects = loadProjects();
  const projectIndex = projects.findIndex(p => p.id === id);
  
  if (projectIndex === -1) {
    return null;
  }
  
  projects[projectIndex] = {
    ...projects[projectIndex],
    status,
    error,
    processedAt: status === "completed" || status === "failed" ? new Date().toISOString() : projects[projectIndex].processedAt
  };
  
  saveProjects(projects);
  return projects[projectIndex];
}

export function deleteMCPProject(id: string): boolean {
  const projects = loadProjects();
  const filteredProjects = projects.filter(p => p.id !== id);
  
  if (filteredProjects.length === projects.length) {
    return false;
  }
  
  saveProjects(filteredProjects);
  return true;
}

export function getProjectStats(): {
  total: number;
  pending: number;
  processing: number;
  completed: number;
  failed: number;
  resource_shortage: number;
  expired: number;
} {
  const projects = loadProjects();
  return {
    total: projects.length,
    pending: projects.filter(p => p.status === "pending").length,
    processing: projects.filter(p => p.status === "processing").length,
    completed: projects.filter(p => p.status === "completed").length,
    failed: projects.filter(p => p.status === "failed").length,
    resource_shortage: projects.filter(p => p.status === "resource_shortage").length,
    expired: projects.filter(p => p.status === "expired").length
  };
}

export function updateMCPProjectResourceShortage(id: string, hasShortage: boolean): ProcessedMCPProject | null {
  const projects = loadProjects();
  const projectIndex = projects.findIndex(p => p.id === id);
  
  if (projectIndex === -1) {
    return null;
  }
  
  projects[projectIndex] = {
    ...projects[projectIndex],
    status: hasShortage ? "resource_shortage" : projects[projectIndex].status,
    hasResourceShortage: hasShortage
  };
  
  saveProjects(projects);
  return projects[projectIndex];
}

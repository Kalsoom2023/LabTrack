import * as fs from "fs";
import * as path from "path";

const DATA_DIR = path.join(process.cwd(), "server", "data");
const DATA_FILE = path.join(DATA_DIR, "data.json");

interface DataStore {
  users: User[];
  labs: Lab[];
  resources: Resource[];
  categories: ResourceCategory[];
  alerts: Alert[];
  reservations: Reservation[];
  projects: Project[];
  projectResources: ProjectResource[];
  projectTeamMembers: ProjectTeamMember[];
  reports: Report[];
}

function ensureDataDirectory(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadAllData(): DataStore {
  ensureDataDirectory();
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error loading data.json:", error);
  }
  return getInitialData();
}

function saveAllData(data: DataStore): void {
  ensureDataDirectory();
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error saving data.json:", error);
    throw error;
  }
}

export interface User {
  userId: number;
  name: string;
  role: string;
  email: string;
  username: string;
  password: string;
  isAllocated?: boolean;
  allocatedToProjectId?: string | null;
}

export interface Lab {
  labId: number;
  labName: string;
  location: string;
  inchargeName: string;
  labCapacity: number;
  usedCapacity?: number;
  openTime: string;
  closeTime: string;
  maintenanceDay: string;
  status?: string;
}

export interface Resource {
  resourceId: number;
  labId: number;
  categoryId: number;
  name: string;
  category: string;
  quantity: number;
  allocatedQuantity?: number;
  status: string;
  thresholdLevel: number;
  warrantyExpiry: string;
}

export interface Alert {
  alertId: number;
  resourceId?: number;
  projectId?: string;
  alertType: string;
  message: string;
  createdOn: string;
  resolvedOn?: string | null;
  isResolved: boolean;
  severity: "High" | "Medium" | "Low";
  sentToAgent?: boolean;
}

export interface Reservation {
  reservationId: number;
  resourceId: number;
  labId: number;
  userId: number;
  startTime: string;
  endTime: string;
  purpose: string;
  status: string;
  approvedBy?: number;
}

export interface Project {
  projectId: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  status: string;
  labId: number;
}

export interface ProjectResource {
  projectResourceId: number;
  projectId: number | string;
  resourceId: number;
  allocatedQuantity: number;
}

export interface ProjectTeamMember {
  id: number;
  projectId: string;
  userId: number;
  role: string;
  allocatedAt: string;
}

export interface ResourceCategory {
  categoryId: number;
  name: string;
  description: string;
}

export interface Report {
  reportId: number;
  title: string;
  type: "Project Completion" | "Resource Utilization" | "Lab Capacity" | "Inventory" | "Users";
  projectId?: string;
  dateCreated: string;
  status: "Ready" | "Processing";
  data: any;
}

function getInitialData(): DataStore {
  return {
    users: [
      { userId: 1, name: "Ayesha Malik", role: "Administrator", email: "ayesha@university.com", username: "ayeshaM", password: "admin22", isAllocated: false, allocatedToProjectId: null },
      { userId: 2, name: "Ali Raza", role: "Manager", email: "ali@university.com", username: "ali01", password: "pass123", isAllocated: false, allocatedToProjectId: null },
      { userId: 3, name: "Sara Khan", role: "Assistant", email: "sara@university.com", username: "sara_k", password: "lab123", isAllocated: false, allocatedToProjectId: null },
      { userId: 4, name: "John Smith", role: "Technician", email: "john@university.com", username: "john_s", password: "tech22", isAllocated: false, allocatedToProjectId: null },
      { userId: 5, name: "Emma Wilson", role: "Student", email: "emma@university.com", username: "emma_w", password: "pass456", isAllocated: false, allocatedToProjectId: null },
      { userId: 6, name: "Ahmed Hassan", role: "Faculty", email: "ahmed@university.com", username: "ahmed_h", password: "pass789", isAllocated: false, allocatedToProjectId: null },
      { userId: 7, name: "Dr. Amir Khan", role: "AI/ML Engineer", email: "amir@university.com", username: "amir_k", password: "ai123", isAllocated: false, allocatedToProjectId: null },
      { userId: 8, name: "Fatima Ali", role: "Frontend Developer", email: "fatima@university.com", username: "fatima_a", password: "dev123", isAllocated: false, allocatedToProjectId: null },
      { userId: 9, name: "Bilal Ahmed", role: "UI/UX Designer", email: "bilal@university.com", username: "bilal_a", password: "design123", isAllocated: false, allocatedToProjectId: null },
      { userId: 10, name: "Hassan Ali", role: "Backend Developer", email: "hassan@university.com", username: "hassan_a", password: "back123", isAllocated: false, allocatedToProjectId: null },
      { userId: 11, name: "Zainab Fatima", role: "Data Scientist", email: "zainab@university.com", username: "zainab_f", password: "data123", isAllocated: false, allocatedToProjectId: null },
      { userId: 12, name: "Omar Farooq", role: "DevOps Engineer", email: "omar@university.com", username: "omar_f", password: "ops123", isAllocated: false, allocatedToProjectId: null },
    ],
    labs: [
      { labId: 1, labName: "Computer Lab 1", location: "Block E - Room 501", inchargeName: "Sir Usman", labCapacity: 50, openTime: "09:00", closeTime: "18:00", maintenanceDay: "Monday", status: "Open" },
      { labId: 2, labName: "Computer Lab 2", location: "Block E - Room 502", inchargeName: "Miss Aisha", labCapacity: 45, openTime: "09:00", closeTime: "17:00", maintenanceDay: "Tuesday", status: "Open" },
      { labId: 3, labName: "Networking Lab", location: "Block F - Room 301", inchargeName: "Engr. Hassan", labCapacity: 35, openTime: "08:30", closeTime: "16:00", maintenanceDay: "Wednesday", status: "Open" },
      { labId: 4, labName: "AI & Machine Learning Lab", location: "Block G - Room 210", inchargeName: "Dr. Adeel", labCapacity: 40, openTime: "09:00", closeTime: "18:00", maintenanceDay: "Thursday", status: "Open" },
      { labId: 5, labName: "Cyber Security Lab", location: "Block F - Room 305", inchargeName: "Sir Kamran", labCapacity: 30, openTime: "10:00", closeTime: "16:00", maintenanceDay: "Friday", status: "Open" },
      { labId: 6, labName: "Software Engineering Lab", location: "Block E - Room 503", inchargeName: "Miss Rabia", labCapacity: 55, openTime: "08:00", closeTime: "15:00", maintenanceDay: "Saturday", status: "Open" },
      { labId: 7, labName: "Data Science Lab", location: "Block G - Room 211", inchargeName: "Dr. Farah", labCapacity: 60, openTime: "09:00", closeTime: "17:00", maintenanceDay: "Sunday", status: "Open" },
    ],
    resources: [
      { resourceId: 1, labId: 1, categoryId: 1, name: "Dell OptiPlex Desktop PC", category: "Desktop PCs", quantity: 20, allocatedQuantity: 0, status: "Available", thresholdLevel: 5, warrantyExpiry: "2028-05-10" },
      { resourceId: 2, labId: 2, categoryId: 2, name: "HP EliteBook Laptop", category: "Laptops", quantity: 15, allocatedQuantity: 0, status: "Available", thresholdLevel: 3, warrantyExpiry: "2027-11-01" },
      { resourceId: 3, labId: 3, categoryId: 3, name: "Cisco Switch 2960", category: "Networking Devices", quantity: 6, allocatedQuantity: 0, status: "Available", thresholdLevel: 1, warrantyExpiry: "2029-03-20" },
      { resourceId: 4, labId: 4, categoryId: 4, name: "Dell PowerEdge Server", category: "Servers", quantity: 3, allocatedQuantity: 0, status: "Available", thresholdLevel: 1, warrantyExpiry: "2030-01-15" },
      { resourceId: 5, labId: 5, categoryId: 5, name: "Samsung 24-inch Monitor", category: "Monitors", quantity: 30, allocatedQuantity: 0, status: "Available", thresholdLevel: 5, warrantyExpiry: "2031-08-01" },
      { resourceId: 6, labId: 6, categoryId: 6, name: "Logitech Keyboard and Mouse Set", category: "Input Devices", quantity: 40, allocatedQuantity: 0, status: "Available", thresholdLevel: 10, warrantyExpiry: "2032-06-11" },
      { resourceId: 7, labId: 7, categoryId: 7, name: "HDMI Cable Set", category: "Accessories", quantity: 50, allocatedQuantity: 0, status: "Available", thresholdLevel: 15, warrantyExpiry: "2033-12-30" },
      { resourceId: 8, labId: 4, categoryId: 8, name: "NVIDIA RTX GPU", category: "AI Hardware", quantity: 8, allocatedQuantity: 0, status: "Available", thresholdLevel: 2, warrantyExpiry: "2029-06-15" },
      { resourceId: 9, labId: 7, categoryId: 9, name: "Python/TensorFlow Workstation", category: "AI Workstations", quantity: 10, allocatedQuantity: 0, status: "Available", thresholdLevel: 2, warrantyExpiry: "2028-12-01" },
    ],
    categories: [
      { categoryId: 1, name: "Desktop PCs", description: "High-performance desktop computers" },
      { categoryId: 2, name: "Laptops", description: "Portable computing devices" },
      { categoryId: 3, name: "Networking Devices", description: "Routers, switches, access points" },
      { categoryId: 4, name: "Servers", description: "Backend computing machines" },
      { categoryId: 5, name: "Monitors", description: "LCD / LED display screens" },
      { categoryId: 6, name: "Input Devices", description: "Keyboards, mice, scanners" },
      { categoryId: 7, name: "Accessories", description: "Cables, headphones, adapters" },
      { categoryId: 8, name: "AI Hardware", description: "GPUs and specialized AI hardware" },
      { categoryId: 9, name: "AI Workstations", description: "Pre-configured AI development stations" },
    ],
    alerts: [],
    reservations: [],
    projects: [],
    projectResources: [],
    projectTeamMembers: [],
    reports: [],
  };
}

export function initializeAllData(): void {
  if (!fs.existsSync(DATA_FILE)) {
    saveAllData(getInitialData());
  }
}

export const dataStorage = {
  getAllUsers: (): User[] => {
    const data = loadAllData();
    return data.users;
  },
  getUserById: (userId: number): User | null => {
    const data = loadAllData();
    return data.users.find(u => u.userId === userId) || null;
  },
  getUserByUsername: (username: string): User | null => {
    const data = loadAllData();
    return data.users.find(u => u.username === username) || null;
  },
  createUser: (user: Omit<User, "userId">): User => {
    const data = loadAllData();
    const newUser: User = { ...user, userId: Math.max(0, ...data.users.map(u => u.userId)) + 1 };
    data.users.push(newUser);
    saveAllData(data);
    return newUser;
  },
  updateUser: (userId: number, updates: Partial<User>): User | null => {
    const data = loadAllData();
    const index = data.users.findIndex(u => u.userId === userId);
    if (index === -1) return null;
    data.users[index] = { ...data.users[index], ...updates };
    saveAllData(data);
    return data.users[index];
  },
  deleteUser: (userId: number): boolean => {
    const data = loadAllData();
    const filtered = data.users.filter(u => u.userId !== userId);
    if (filtered.length === data.users.length) return false;
    data.users = filtered;
    saveAllData(data);
    return true;
  },
  getAvailableUsers: (): User[] => {
    const data = loadAllData();
    return data.users.filter(u => !u.isAllocated);
  },
  allocateUser: (userId: number, projectId: string): User | null => {
    const data = loadAllData();
    const index = data.users.findIndex(u => u.userId === userId);
    if (index === -1) return null;
    if (data.users[index].isAllocated) return null;
    data.users[index].isAllocated = true;
    data.users[index].allocatedToProjectId = projectId;
    saveAllData(data);
    return data.users[index];
  },
  deallocateUser: (userId: number): User | null => {
    const data = loadAllData();
    const index = data.users.findIndex(u => u.userId === userId);
    if (index === -1) return null;
    data.users[index].isAllocated = false;
    data.users[index].allocatedToProjectId = null;
    saveAllData(data);
    return data.users[index];
  },

  getAllLabs: (): Lab[] => {
    const data = loadAllData();
    return data.labs;
  },
  getLabById: (labId: number): Lab | null => {
    const data = loadAllData();
    return data.labs.find(l => l.labId === labId) || null;
  },
  createLab: (lab: Omit<Lab, "labId">): Lab => {
    const data = loadAllData();
    const newLab: Lab = { ...lab, labId: Math.max(0, ...data.labs.map(l => l.labId)) + 1 };
    data.labs.push(newLab);
    saveAllData(data);
    return newLab;
  },
  updateLab: (labId: number, updates: Partial<Lab>): Lab | null => {
    const data = loadAllData();
    const index = data.labs.findIndex(l => l.labId === labId);
    if (index === -1) return null;
    data.labs[index] = { ...data.labs[index], ...updates };
    saveAllData(data);
    return data.labs[index];
  },
  deleteLab: (labId: number): boolean => {
    const data = loadAllData();
    const filtered = data.labs.filter(l => l.labId !== labId);
    if (filtered.length === data.labs.length) return false;
    data.labs = filtered;
    saveAllData(data);
    return true;
  },
  getLabAvailableCapacity: (labId: number): number => {
    const lab = dataStorage.getLabById(labId);
    if (!lab) return 0;
    return lab.labCapacity - (lab.usedCapacity || 0);
  },
  allocateLabCapacity: (labId: number, count: number): boolean => {
    const data = loadAllData();
    const index = data.labs.findIndex(l => l.labId === labId);
    if (index === -1) return false;
    const available = data.labs[index].labCapacity - (data.labs[index].usedCapacity || 0);
    if (available < count) return false;
    data.labs[index].usedCapacity = (data.labs[index].usedCapacity || 0) + count;
    saveAllData(data);
    return true;
  },
  deallocateLabCapacity: (labId: number, count: number): boolean => {
    const data = loadAllData();
    const index = data.labs.findIndex(l => l.labId === labId);
    if (index === -1) return false;
    data.labs[index].usedCapacity = Math.max(0, (data.labs[index].usedCapacity || 0) - count);
    saveAllData(data);
    return true;
  },

  getAllResources: (): Resource[] => {
    const data = loadAllData();
    return data.resources;
  },
  getResourceById: (resourceId: number): Resource | null => {
    const data = loadAllData();
    return data.resources.find(r => r.resourceId === resourceId) || null;
  },
  getResourcesByLabId: (labId: number): Resource[] => {
    const data = loadAllData();
    return data.resources.filter(r => r.labId === labId);
  },
  createResource: (resource: Omit<Resource, "resourceId">): Resource => {
    const data = loadAllData();
    const newResource: Resource = { ...resource, resourceId: Math.max(0, ...data.resources.map(r => r.resourceId)) + 1 };
    data.resources.push(newResource);
    saveAllData(data);
    return newResource;
  },
  updateResource: (resourceId: number, updates: Partial<Resource>): Resource | null => {
    const data = loadAllData();
    const index = data.resources.findIndex(r => r.resourceId === resourceId);
    if (index === -1) return null;
    data.resources[index] = { ...data.resources[index], ...updates };
    saveAllData(data);
    return data.resources[index];
  },
  deleteResource: (resourceId: number): boolean => {
    const data = loadAllData();
    const filtered = data.resources.filter(r => r.resourceId !== resourceId);
    if (filtered.length === data.resources.length) return false;
    data.resources = filtered;
    saveAllData(data);
    return true;
  },
  getAvailableQuantity: (resourceId: number): number => {
    const resource = dataStorage.getResourceById(resourceId);
    if (!resource) return 0;
    return resource.quantity - (resource.allocatedQuantity || 0);
  },
  allocateResource: (resourceId: number, quantity: number, projectId: string): boolean => {
    const data = loadAllData();
    const index = data.resources.findIndex(r => r.resourceId === resourceId);
    if (index === -1) return false;
    const available = data.resources[index].quantity - (data.resources[index].allocatedQuantity || 0);
    if (available < quantity) return false;
    data.resources[index].allocatedQuantity = (data.resources[index].allocatedQuantity || 0) + quantity;
    saveAllData(data);
    return true;
  },
  deallocateResource: (resourceId: number, quantity: number): boolean => {
    const data = loadAllData();
    const index = data.resources.findIndex(r => r.resourceId === resourceId);
    if (index === -1) return false;
    data.resources[index].allocatedQuantity = Math.max(0, (data.resources[index].allocatedQuantity || 0) - quantity);
    saveAllData(data);
    return true;
  },

  getAllAlerts: (): Alert[] => {
    const data = loadAllData();
    return data.alerts;
  },
  getAlertById: (alertId: number): Alert | null => {
    const data = loadAllData();
    return data.alerts.find(a => a.alertId === alertId) || null;
  },
  getUnresolvedAlerts: (): Alert[] => {
    const data = loadAllData();
    return data.alerts.filter(a => !a.isResolved);
  },
  getAlertsForAgent: (): Alert[] => {
    const data = loadAllData();
    return data.alerts.filter(a => !a.isResolved && !a.sentToAgent);
  },
  createAlert: (alert: Omit<Alert, "alertId" | "createdOn">): Alert => {
    const data = loadAllData();
    const newAlert: Alert = {
      ...alert,
      alertId: Math.max(0, ...data.alerts.map(a => a.alertId), 0) + 1,
      createdOn: new Date().toISOString(),
      isResolved: false,
      sentToAgent: false,
    };
    data.alerts.push(newAlert);
    saveAllData(data);
    return newAlert;
  },
  updateAlert: (alertId: number, updates: Partial<Alert>): Alert | null => {
    const data = loadAllData();
    const index = data.alerts.findIndex(a => a.alertId === alertId);
    if (index === -1) return null;
    data.alerts[index] = { ...data.alerts[index], ...updates };
    saveAllData(data);
    return data.alerts[index];
  },
  resolveAlert: (alertId: number): Alert | null => {
    const data = loadAllData();
    const index = data.alerts.findIndex(a => a.alertId === alertId);
    if (index === -1) return null;
    data.alerts[index].isResolved = true;
    data.alerts[index].resolvedOn = new Date().toISOString();
    saveAllData(data);
    return data.alerts[index];
  },
  markAlertSentToAgent: (alertId: number): Alert | null => {
    const data = loadAllData();
    const index = data.alerts.findIndex(a => a.alertId === alertId);
    if (index === -1) return null;
    data.alerts[index].sentToAgent = true;
    saveAllData(data);
    return data.alerts[index];
  },
  deleteAlert: (alertId: number): boolean => {
    const data = loadAllData();
    const filtered = data.alerts.filter(a => a.alertId !== alertId);
    if (filtered.length === data.alerts.length) return false;
    data.alerts = filtered;
    saveAllData(data);
    return true;
  },

  getAllReservations: (): Reservation[] => {
    const data = loadAllData();
    return data.reservations;
  },
  getReservationById: (reservationId: number): Reservation | null => {
    const data = loadAllData();
    return data.reservations.find(r => r.reservationId === reservationId) || null;
  },
  getReservationsByUserId: (userId: number): Reservation[] => {
    const data = loadAllData();
    return data.reservations.filter(r => r.userId === userId);
  },
  createReservation: (reservation: Omit<Reservation, "reservationId">): Reservation => {
    const data = loadAllData();
    const newReservation: Reservation = { ...reservation, reservationId: Math.max(0, ...data.reservations.map(r => r.reservationId), 0) + 1 };
    data.reservations.push(newReservation);
    saveAllData(data);
    return newReservation;
  },
  updateReservation: (reservationId: number, updates: Partial<Reservation>): Reservation | null => {
    const data = loadAllData();
    const index = data.reservations.findIndex(r => r.reservationId === reservationId);
    if (index === -1) return null;
    data.reservations[index] = { ...data.reservations[index], ...updates };
    saveAllData(data);
    return data.reservations[index];
  },
  deleteReservation: (reservationId: number): boolean => {
    const data = loadAllData();
    const filtered = data.reservations.filter(r => r.reservationId !== reservationId);
    if (filtered.length === data.reservations.length) return false;
    data.reservations = filtered;
    saveAllData(data);
    return true;
  },

  getAllProjects: (): Project[] => {
    const data = loadAllData();
    return data.projects;
  },
  getProjectById: (projectId: number): Project | null => {
    const data = loadAllData();
    return data.projects.find(p => p.projectId === projectId) || null;
  },
  getProjectsByLabId: (labId: number): Project[] => {
    const data = loadAllData();
    return data.projects.filter(p => p.labId === labId);
  },
  createProject: (project: Omit<Project, "projectId">): Project => {
    const data = loadAllData();
    const newProject: Project = { ...project, projectId: Math.max(0, ...data.projects.map(p => p.projectId), 0) + 1 };
    data.projects.push(newProject);
    saveAllData(data);
    return newProject;
  },
  updateProject: (projectId: number, updates: Partial<Project>): Project | null => {
    const data = loadAllData();
    const index = data.projects.findIndex(p => p.projectId === projectId);
    if (index === -1) return null;
    data.projects[index] = { ...data.projects[index], ...updates };
    saveAllData(data);
    return data.projects[index];
  },
  deleteProject: (projectId: number): boolean => {
    const data = loadAllData();
    const filtered = data.projects.filter(p => p.projectId !== projectId);
    if (filtered.length === data.projects.length) return false;
    data.projects = filtered;
    saveAllData(data);
    return true;
  },

  getAllProjectResources: (): ProjectResource[] => {
    const data = loadAllData();
    return data.projectResources;
  },
  getProjectResourcesByProjectId: (projectId: number | string): ProjectResource[] => {
    const data = loadAllData();
    return data.projectResources.filter(pr => pr.projectId === projectId || pr.projectId === String(projectId));
  },
  createProjectResource: (projectResource: Omit<ProjectResource, "projectResourceId">): ProjectResource => {
    const data = loadAllData();
    const newPR: ProjectResource = { ...projectResource, projectResourceId: Math.max(0, ...data.projectResources.map(pr => pr.projectResourceId), 0) + 1 };
    data.projectResources.push(newPR);
    saveAllData(data);
    return newPR;
  },
  deleteProjectResourcesByProjectId: (projectId: number | string): void => {
    const data = loadAllData();
    data.projectResources = data.projectResources.filter(pr => pr.projectId !== projectId && pr.projectId !== String(projectId));
    saveAllData(data);
  },

  getAllProjectTeamMembers: (): ProjectTeamMember[] => {
    const data = loadAllData();
    return data.projectTeamMembers;
  },
  getProjectTeamMembersByProjectId: (projectId: string): ProjectTeamMember[] => {
    const data = loadAllData();
    return data.projectTeamMembers.filter(m => m.projectId === projectId);
  },
  createProjectTeamMember: (member: Omit<ProjectTeamMember, "id" | "allocatedAt">): ProjectTeamMember => {
    const data = loadAllData();
    const newMember: ProjectTeamMember = {
      ...member,
      id: Math.max(0, ...data.projectTeamMembers.map(m => m.id), 0) + 1,
      allocatedAt: new Date().toISOString(),
    };
    data.projectTeamMembers.push(newMember);
    saveAllData(data);
    return newMember;
  },
  deleteProjectTeamMembersByProjectId: (projectId: string): void => {
    const data = loadAllData();
    data.projectTeamMembers = data.projectTeamMembers.filter(m => m.projectId !== projectId);
    saveAllData(data);
  },

  getAllResourceCategories: (): ResourceCategory[] => {
    const data = loadAllData();
    return data.categories;
  },
  getResourceCategoryById: (categoryId: number): ResourceCategory | null => {
    const data = loadAllData();
    return data.categories.find(c => c.categoryId === categoryId) || null;
  },
  createResourceCategory: (category: Omit<ResourceCategory, "categoryId">): ResourceCategory => {
    const data = loadAllData();
    const newCategory: ResourceCategory = { ...category, categoryId: Math.max(0, ...data.categories.map(c => c.categoryId)) + 1 };
    data.categories.push(newCategory);
    saveAllData(data);
    return newCategory;
  },
  updateResourceCategory: (categoryId: number, updates: Partial<ResourceCategory>): ResourceCategory | null => {
    const data = loadAllData();
    const index = data.categories.findIndex(c => c.categoryId === categoryId);
    if (index === -1) return null;
    data.categories[index] = { ...data.categories[index], ...updates };
    saveAllData(data);
    return data.categories[index];
  },
  deleteResourceCategory: (categoryId: number): boolean => {
    const data = loadAllData();
    const filtered = data.categories.filter(c => c.categoryId !== categoryId);
    if (filtered.length === data.categories.length) return false;
    data.categories = filtered;
    saveAllData(data);
    return true;
  },

  getAllReports: (): Report[] => {
    const data = loadAllData();
    return data.reports || [];
  },
  getReportById: (reportId: number): Report | null => {
    const data = loadAllData();
    return (data.reports || []).find(r => r.reportId === reportId) || null;
  },
  getReportsByProjectId: (projectId: string): Report[] => {
    const data = loadAllData();
    return (data.reports || []).filter(r => r.projectId === projectId);
  },
  createReport: (report: Omit<Report, "reportId" | "dateCreated">): Report => {
    const data = loadAllData();
    if (!data.reports) data.reports = [];
    const newReport: Report = {
      ...report,
      reportId: Math.max(0, ...data.reports.map(r => r.reportId), 0) + 1,
      dateCreated: new Date().toISOString(),
    };
    data.reports.push(newReport);
    saveAllData(data);
    return newReport;
  },
  deleteReport: (reportId: number): boolean => {
    const data = loadAllData();
    if (!data.reports) return false;
    const filtered = data.reports.filter(r => r.reportId !== reportId);
    if (filtered.length === data.reports.length) return false;
    data.reports = filtered;
    saveAllData(data);
    return true;
  },
};

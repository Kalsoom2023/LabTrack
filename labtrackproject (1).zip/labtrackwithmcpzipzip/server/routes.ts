import { Router, type Request, type Response } from "express";
import { dataStorage, initializeAllData } from "./services/dataStorage";

const router = Router();

initializeAllData();

router.post("/api/auth/login", async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: "Username and password required" });
    }

    const user = dataStorage.getUserByUsername(username);

    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const userData = {
      userId: user.userId,
      username: user.username,
      name: user.name,
      role: user.role,
      email: user.email,
    };

    (req.session as any).userId = user.userId;
    (req.session as any).user = userData;

    res.json({ user: userData });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/api/auth/logout", (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: "Logout failed" });
    }
    res.json({ message: "Logged out successfully" });
  });
});

router.get("/api/auth/me", (req: Request, res: Response) => {
  if ((req.session as any).userId) {
    res.json({ user: (req.session as any).user });
  } else {
    res.status(401).json({ error: "Not authenticated" });
  }
});

router.get("/api/users", async (req: Request, res: Response) => {
  try {
    const users = dataStorage.getAllUsers();
    res.json(users.map(u => ({ ...u, password: undefined })));
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

router.get("/api/users/available", async (req: Request, res: Response) => {
  try {
    const users = dataStorage.getAvailableUsers();
    res.json(users.map(u => ({ ...u, password: undefined })));
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch available users" });
  }
});

router.get("/api/users/:userId", async (req: Request, res: Response) => {
  try {
    const user = dataStorage.getUserById(parseInt(req.params.userId));
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ ...user, password: undefined });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch user" });
  }
});

router.post("/api/users", async (req: Request, res: Response) => {
  try {
    const user = dataStorage.createUser(req.body);
    res.status(201).json({ ...user, password: undefined });
  } catch (error) {
    res.status(500).json({ error: "Failed to create user" });
  }
});

router.put("/api/users/:userId", async (req: Request, res: Response) => {
  try {
    const user = dataStorage.updateUser(parseInt(req.params.userId), req.body);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ ...user, password: undefined });
  } catch (error) {
    res.status(500).json({ error: "Failed to update user" });
  }
});

router.delete("/api/users/:userId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteUser(parseInt(req.params.userId));
    if (!deleted) return res.status(404).json({ error: "User not found" });
    res.json({ message: "User deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete user" });
  }
});

router.get("/api/labs", async (req: Request, res: Response) => {
  try {
    const labs = dataStorage.getAllLabs();
    res.json(labs);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch labs" });
  }
});

router.get("/api/labs/:labId", async (req: Request, res: Response) => {
  try {
    const lab = dataStorage.getLabById(parseInt(req.params.labId));
    if (!lab) return res.status(404).json({ error: "Lab not found" });
    res.json(lab);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch lab" });
  }
});

router.post("/api/labs", async (req: Request, res: Response) => {
  try {
    const lab = dataStorage.createLab(req.body);
    res.status(201).json(lab);
  } catch (error) {
    res.status(500).json({ error: "Failed to create lab" });
  }
});

router.put("/api/labs/:labId", async (req: Request, res: Response) => {
  try {
    const lab = dataStorage.updateLab(parseInt(req.params.labId), req.body);
    if (!lab) return res.status(404).json({ error: "Lab not found" });
    res.json(lab);
  } catch (error) {
    res.status(500).json({ error: "Failed to update lab" });
  }
});

router.delete("/api/labs/:labId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteLab(parseInt(req.params.labId));
    if (!deleted) return res.status(404).json({ error: "Lab not found" });
    res.json({ message: "Lab deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete lab" });
  }
});

router.get("/api/resources", async (req: Request, res: Response) => {
  try {
    const resources = dataStorage.getAllResources();
    res.json(resources);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch resources" });
  }
});

router.get("/api/resources/:resourceId", async (req: Request, res: Response) => {
  try {
    const resource = dataStorage.getResourceById(parseInt(req.params.resourceId));
    if (!resource) return res.status(404).json({ error: "Resource not found" });
    res.json(resource);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch resource" });
  }
});

router.get("/api/labs/:labId/resources", async (req: Request, res: Response) => {
  try {
    const resources = dataStorage.getResourcesByLabId(parseInt(req.params.labId));
    res.json(resources);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch resources" });
  }
});

router.post("/api/resources", async (req: Request, res: Response) => {
  try {
    const resource = dataStorage.createResource(req.body);
    res.status(201).json(resource);
  } catch (error) {
    res.status(500).json({ error: "Failed to create resource" });
  }
});

router.put("/api/resources/:resourceId", async (req: Request, res: Response) => {
  try {
    const resource = dataStorage.updateResource(parseInt(req.params.resourceId), req.body);
    if (!resource) return res.status(404).json({ error: "Resource not found" });
    res.json(resource);
  } catch (error) {
    res.status(500).json({ error: "Failed to update resource" });
  }
});

router.delete("/api/resources/:resourceId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteResource(parseInt(req.params.resourceId));
    if (!deleted) return res.status(404).json({ error: "Resource not found" });
    res.json({ message: "Resource deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete resource" });
  }
});

router.get("/api/resource-categories", async (req: Request, res: Response) => {
  try {
    const categories = dataStorage.getAllResourceCategories();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

router.get("/api/categories", async (req: Request, res: Response) => {
  try {
    const categories = dataStorage.getAllResourceCategories();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

router.post("/api/resource-categories", async (req: Request, res: Response) => {
  try {
    const category = dataStorage.createResourceCategory(req.body);
    res.status(201).json(category);
  } catch (error) {
    res.status(500).json({ error: "Failed to create category" });
  }
});

router.put("/api/resource-categories/:categoryId", async (req: Request, res: Response) => {
  try {
    const category = dataStorage.updateResourceCategory(parseInt(req.params.categoryId), req.body);
    if (!category) return res.status(404).json({ error: "Category not found" });
    res.json(category);
  } catch (error) {
    res.status(500).json({ error: "Failed to update category" });
  }
});

router.delete("/api/resource-categories/:categoryId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteResourceCategory(parseInt(req.params.categoryId));
    if (!deleted) return res.status(404).json({ error: "Category not found" });
    res.json({ message: "Category deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete category" });
  }
});

router.get("/api/alerts", async (req: Request, res: Response) => {
  try {
    const alerts = dataStorage.getAllAlerts();
    res.json(alerts);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch alerts" });
  }
});

router.get("/api/alerts/unresolved", async (req: Request, res: Response) => {
  try {
    const alerts = dataStorage.getUnresolvedAlerts();
    res.json(alerts);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch unresolved alerts" });
  }
});

router.get("/api/alerts/:alertId", async (req: Request, res: Response) => {
  try {
    const alert = dataStorage.getAlertById(parseInt(req.params.alertId));
    if (!alert) return res.status(404).json({ error: "Alert not found" });
    res.json(alert);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch alert" });
  }
});

router.post("/api/alerts", async (req: Request, res: Response) => {
  try {
    const alert = dataStorage.createAlert(req.body);
    res.status(201).json(alert);
  } catch (error) {
    res.status(500).json({ error: "Failed to create alert" });
  }
});

router.put("/api/alerts/:alertId", async (req: Request, res: Response) => {
  try {
    const alert = dataStorage.updateAlert(parseInt(req.params.alertId), req.body);
    if (!alert) return res.status(404).json({ error: "Alert not found" });
    res.json(alert);
  } catch (error) {
    res.status(500).json({ error: "Failed to update alert" });
  }
});

router.post("/api/alerts/:alertId/resolve", async (req: Request, res: Response) => {
  try {
    const alert = dataStorage.resolveAlert(parseInt(req.params.alertId));
    if (!alert) return res.status(404).json({ error: "Alert not found" });
    res.json(alert);
  } catch (error) {
    res.status(500).json({ error: "Failed to resolve alert" });
  }
});

router.delete("/api/alerts/:alertId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteAlert(parseInt(req.params.alertId));
    if (!deleted) return res.status(404).json({ error: "Alert not found" });
    res.json({ message: "Alert deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete alert" });
  }
});

router.get("/api/reservations", async (req: Request, res: Response) => {
  try {
    const reservations = dataStorage.getAllReservations();
    res.json(reservations);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch reservations" });
  }
});

router.get("/api/reservations/:reservationId", async (req: Request, res: Response) => {
  try {
    const reservation = dataStorage.getReservationById(parseInt(req.params.reservationId));
    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch reservation" });
  }
});

router.get("/api/users/:userId/reservations", async (req: Request, res: Response) => {
  try {
    const reservations = dataStorage.getReservationsByUserId(parseInt(req.params.userId));
    res.json(reservations);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch reservations" });
  }
});

router.post("/api/reservations", async (req: Request, res: Response) => {
  try {
    const reservation = dataStorage.createReservation(req.body);
    res.status(201).json(reservation);
  } catch (error) {
    res.status(500).json({ error: "Failed to create reservation" });
  }
});

router.put("/api/reservations/:reservationId", async (req: Request, res: Response) => {
  try {
    const reservation = dataStorage.updateReservation(parseInt(req.params.reservationId), req.body);
    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ error: "Failed to update reservation" });
  }
});

router.delete("/api/reservations/:reservationId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteReservation(parseInt(req.params.reservationId));
    if (!deleted) return res.status(404).json({ error: "Reservation not found" });
    res.json({ message: "Reservation deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete reservation" });
  }
});

router.post("/api/reservations/:reservationId/approve", async (req: Request, res: Response) => {
  try {
    const reservationId = parseInt(req.params.reservationId);
    const userId = (req.session as any).userId;
    const reservation = dataStorage.updateReservation(reservationId, {
      status: "Approved",
      approvedBy: userId,
    });
    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ error: "Failed to approve reservation" });
  }
});

router.post("/api/reservations/:reservationId/reject", async (req: Request, res: Response) => {
  try {
    const reservationId = parseInt(req.params.reservationId);
    const reservation = dataStorage.updateReservation(reservationId, {
      status: "Rejected",
    });
    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    res.json(reservation);
  } catch (error) {
    res.status(500).json({ error: "Failed to reject reservation" });
  }
});

router.get("/api/projects", async (req: Request, res: Response) => {
  try {
    const projects = dataStorage.getAllProjects();
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

router.get("/api/projects/:projectId", async (req: Request, res: Response) => {
  try {
    const project = dataStorage.getProjectById(parseInt(req.params.projectId));
    if (!project) return res.status(404).json({ error: "Project not found" });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch project" });
  }
});

router.get("/api/labs/:labId/projects", async (req: Request, res: Response) => {
  try {
    const projects = dataStorage.getProjectsByLabId(parseInt(req.params.labId));
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

router.post("/api/projects", async (req: Request, res: Response) => {
  try {
    const project = dataStorage.createProject(req.body);
    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ error: "Failed to create project" });
  }
});

router.put("/api/projects/:projectId", async (req: Request, res: Response) => {
  try {
    const project = dataStorage.updateProject(parseInt(req.params.projectId), req.body);
    if (!project) return res.status(404).json({ error: "Project not found" });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: "Failed to update project" });
  }
});

router.delete("/api/projects/:projectId", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteProject(parseInt(req.params.projectId));
    if (!deleted) return res.status(404).json({ error: "Project not found" });
    res.json({ message: "Project deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete project" });
  }
});

router.get("/api/project-resources", async (req: Request, res: Response) => {
  try {
    const projectResources = dataStorage.getAllProjectResources();
    res.json(projectResources);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch project resources" });
  }
});

router.get("/api/projects/:projectId/resources", async (req: Request, res: Response) => {
  try {
    const projectResources = dataStorage.getProjectResourcesByProjectId(req.params.projectId);
    res.json(projectResources);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch project resources" });
  }
});

router.get("/api/projects/:projectId/team", async (req: Request, res: Response) => {
  try {
    const teamMembers = dataStorage.getProjectTeamMembersByProjectId(req.params.projectId);
    res.json(teamMembers);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch project team members" });
  }
});

export default router;

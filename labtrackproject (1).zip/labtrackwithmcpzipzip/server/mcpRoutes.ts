import { Router, type Request, type Response } from "express";
import {
  analyzeProjectWithAI,
  generateFallbackRecommendations,
  MCPProjectInput,
  AIRecommendation,
} from "./services/agenticAI";
import {
  getAllMCPProjects,
  getMCPProjectById,
  createMCPProject,
  updateMCPProjectWithRecommendations,
  updateMCPProjectStatus,
  deleteMCPProject,
  getProjectStats,
  updateMCPProjectResourceShortage,
} from "./services/mcpStorage";
import { dataStorage } from "./services/dataStorage";

const router = Router();

function getDataForAI() {
  const labs = dataStorage.getAllLabs().map((l) => ({
    labId: l.labId,
    labName: l.labName,
    location: l.location,
    inchargeName: l.inchargeName,
    labCapacity: l.labCapacity,
  }));

  const resources = dataStorage.getAllResources().map((r) => ({
    resourceId: r.resourceId,
    labId: r.labId,
    name: r.name,
    category: r.category,
    quantity: r.quantity,
    allocatedQuantity: r.allocatedQuantity || 0,
    availableQuantity: r.quantity - (r.allocatedQuantity || 0),
    status: r.status,
  }));

  const users = dataStorage.getAllUsers().map((u) => ({
    userId: u.userId,
    name: u.name,
    role: u.role,
    email: u.email,
    isAllocated: u.isAllocated || false,
    allocatedToProjectId: u.allocatedToProjectId,
  }));

  return { labs, resources, users };
}

function applyAllocation(
  projectId: string,
  recommendations: AIRecommendation,
): {
  alerts: any[];
  appliedTeam: any[];
  appliedResources: any[];
  labsUsed: { labId: number; membersAllocated: number }[];
} {
  const alerts: any[] = [];
  const appliedTeam: any[] = [];
  const appliedResources: any[] = [];
  const labsUsed: { labId: number; membersAllocated: number }[] = [];
  const users = dataStorage.getAllUsers();
  const resources = dataStorage.getAllResources();
  const labs = dataStorage.getAllLabs();

  for (const teamAlloc of recommendations.team_allocation) {
    if (teamAlloc.assigned_member) {
      const user = users.find(
        (u) =>
          u.name.toLowerCase() === teamAlloc.assigned_member!.toLowerCase(),
      );

      if (!user) {
        alerts.push({
          alertType: "Missing HR Resource",
          message: `Required team member "${teamAlloc.assigned_member}" for role "${teamAlloc.role}" not found in system`,
          severity: "High" as const,
          projectId,
          resourceId: undefined,
        });
        continue;
      }

      if (user.isAllocated) {
        alerts.push({
          alertType: "HR Already Allocated",
          message: `Team member "${user.name}" is already allocated to project ${user.allocatedToProjectId}. Cannot allocate to role "${teamAlloc.role}"`,
          severity: "Medium" as const,
          projectId,
          resourceId: undefined,
        });
        teamAlloc.availability_status = "unavailable";
        teamAlloc.allocation_reasoning = `${user.name} is already allocated to another project`;
        continue;
      }

      const allocated = dataStorage.allocateUser(user.userId, projectId);
      if (allocated) {
        dataStorage.createProjectTeamMember({
          projectId,
          userId: user.userId,
          role: teamAlloc.role,
        });
        appliedTeam.push({
          userId: user.userId,
          name: user.name,
          role: teamAlloc.role,
        });
        teamAlloc.availability_status = "available";
        teamAlloc.allocation_reasoning = `Successfully allocated ${user.name} to ${teamAlloc.role}`;
      }
    } else {
      alerts.push({
        alertType: "Missing HR Resource",
        message: `No available team member found for role "${teamAlloc.role}"`,
        severity: "Medium" as const,
        projectId,
        resourceId: undefined,
      });
    }
  }

  for (const resourceAlloc of recommendations.resource_allocation) {
    const matchingResource = resources.find(
      (r) =>
        r.name
          .toLowerCase()
          .includes(resourceAlloc.resource.toLowerCase().split(" ")[0]) ||
        resourceAlloc.resource
          .toLowerCase()
          .includes(r.category?.toLowerCase() || ""),
    );

    if (!matchingResource) {
      alerts.push({
        alertType: "Missing Resource",
        message: `Required resource "${resourceAlloc.resource}" not found in inventory`,
        severity: "High" as const,
        projectId,
        resourceId: undefined,
      });
      resourceAlloc.availability_status = "unavailable";
      resourceAlloc.allocation_reasoning = `Resource "${resourceAlloc.resource}" not found in system`;
      continue;
    }

    const availableQty =
      matchingResource.quantity - (matchingResource.allocatedQuantity || 0);
    const neededQty = resourceAlloc.quantity_needed || 1;

    if (availableQty < neededQty) {
      alerts.push({
        alertType: "Insufficient Resource",
        message: `Insufficient "${matchingResource.name}": need ${neededQty}, only ${availableQty} available`,
        severity: availableQty === 0 ? ("High" as const) : ("Medium" as const),
        projectId,
        resourceId: matchingResource.resourceId,
      });

      if (availableQty > 0) {
        const allocated = dataStorage.allocateResource(
          matchingResource.resourceId,
          availableQty,
          projectId,
        );
        if (allocated) {
          dataStorage.createProjectResource({
            projectId,
            resourceId: matchingResource.resourceId,
            allocatedQuantity: availableQty,
          });
          appliedResources.push({
            resourceId: matchingResource.resourceId,
            name: matchingResource.name,
            allocatedQuantity: availableQty,
            requestedQuantity: neededQty,
          });
          resourceAlloc.availability_status = "partial";
          resourceAlloc.allocation_reasoning = `Partially allocated ${availableQty} of ${neededQty} needed`;
        }
      } else {
        resourceAlloc.availability_status = "unavailable";
        resourceAlloc.allocation_reasoning = `No available quantity of ${matchingResource.name}`;
      }
      continue;
    }

    const allocated = dataStorage.allocateResource(
      matchingResource.resourceId,
      neededQty,
      projectId,
    );
    if (allocated) {
      dataStorage.createProjectResource({
        projectId,
        resourceId: matchingResource.resourceId,
        allocatedQuantity: neededQty,
      });
      appliedResources.push({
        resourceId: matchingResource.resourceId,
        name: matchingResource.name,
        allocatedQuantity: neededQty,
        requestedQuantity: neededQty,
      });

      const lab = dataStorage.getLabById(matchingResource.labId);
      resourceAlloc.assigned_lab = lab?.labName || undefined;
      resourceAlloc.availability_status = "available";
      resourceAlloc.allocation_reasoning = `Successfully allocated ${neededQty} x ${matchingResource.name} from ${lab?.labName || "lab"}`;
    }
  }

  for (const alertData of alerts) {
    dataStorage.createAlert(alertData);
  }

  // Allocate lab capacity based on team members assigned
  // Find the primary lab from allocated resources
  if (appliedTeam.length > 0 && appliedResources.length > 0) {
    const primaryResourceId = appliedResources[0].resourceId;
    const primaryResource = resources.find(
      (r) => r.resourceId === primaryResourceId,
    );
    if (primaryResource) {
      const labId = primaryResource.labId;
      const teamCount = appliedTeam.length;
      const allocated = dataStorage.allocateLabCapacity(labId, teamCount);
      if (allocated) {
        labsUsed.push({ labId, membersAllocated: teamCount });
      } else {
        // Lab capacity exceeded - create alert
        const lab = labs.find((l) => l.labId === labId);
        alerts.push({
          alertType: "Lab Capacity Exceeded",
          message: `Lab "${lab?.labName || labId}" capacity exceeded. Cannot accommodate ${teamCount} team members.`,
          severity: "Medium" as const,
          projectId,
          resourceId: undefined,
        });
        dataStorage.createAlert({
          alertType: "Lab Capacity Exceeded",
          message: `Lab "${lab?.labName || labId}" capacity exceeded. Cannot accommodate ${teamCount} team members.`,
          severity: "Medium",
          projectId,
          isResolved: false,
        });
      }
    }
  }

  return { alerts, appliedTeam, appliedResources, labsUsed };
}

function deallocateProjectResources(projectId: string): {
  deallocatedTeam: number;
  deallocatedResources: number;
  labCapacityRestored: { labId: number; count: number }[];
} {
  let deallocatedTeam = 0;
  let deallocatedResources = 0;
  const labCapacityRestored: { labId: number; count: number }[] = [];

  const teamMembers = dataStorage.getProjectTeamMembersByProjectId(projectId);
  const projectResources =
    dataStorage.getProjectResourcesByProjectId(projectId);

  // Find the primary lab from project resources to restore capacity
  if (teamMembers.length > 0 && projectResources.length > 0) {
    const primaryResource = dataStorage.getResourceById(
      projectResources[0].resourceId,
    );
    if (primaryResource) {
      const labId = primaryResource.labId;
      const teamCount = teamMembers.length;
      dataStorage.deallocateLabCapacity(labId, teamCount);
      labCapacityRestored.push({ labId, count: teamCount });
    }
  }

  for (const member of teamMembers) {
    dataStorage.deallocateUser(member.userId);
    deallocatedTeam++;
  }
  dataStorage.deleteProjectTeamMembersByProjectId(projectId);

  for (const pr of projectResources) {
    dataStorage.deallocateResource(pr.resourceId, pr.allocatedQuantity);
    deallocatedResources++;
  }
  dataStorage.deleteProjectResourcesByProjectId(projectId);

  return { deallocatedTeam, deallocatedResources, labCapacityRestored };
}

function generateProjectCompletionReport(
  project: any,
  deallocationResult: any,
): void {
  const teamMembers = project.aiRecommendations?.team_allocation || [];
  const resources = project.aiRecommendations?.resource_allocation || [];

  const reportData = {
    projectId: project.id,
    projectTitle: project.originalInput?.title || "Untitled Project",
    description: project.originalInput?.description || "",
    startDate: project.processedAt,
    endDate: new Date().toISOString(),
    timeline:
      project.aiRecommendations?.timeline_adjustments?.recommended_timeline ||
      "N/A",
    estimatedCost: project.originalInput?.estimated_cost || "N/A",
    complexityLevel: project.originalInput?.complexity_level || "N/A",
    teamAllocated: teamMembers.map((t: any) => ({
      role: t.role,
      member: t.assigned_member,
      status: t.availability_status,
    })),
    resourcesAllocated: resources.map((r: any) => ({
      resource: r.resource,
      quantity: r.quantity_needed,
      lab: r.assigned_lab,
      status: r.availability_status,
    })),
    deallocationSummary: {
      teamDeallocated: deallocationResult.deallocatedTeam,
      resourcesDeallocated: deallocationResult.deallocatedResources,
      labCapacityRestored: deallocationResult.labCapacityRestored,
    },
    hadResourceShortage: project.hasResourceShortage || false,
  };

  dataStorage.createReport({
    title: `Project Completion: ${project.originalInput?.title || project.id}`,
    type: "Project Completion",
    projectId: project.id,
    status: "Ready",
    data: reportData,
  });
}

function checkAndDeallocateExpiredProjects(): {
  expiredProjects: string[];
  deallocations: any[];
  reportsGenerated: number;
} {
  const expiredProjects: string[] = [];
  const deallocations: any[] = [];
  let reportsGenerated = 0;
  const now = new Date();

  const mcpProjects = getAllMCPProjects();
  for (const project of mcpProjects) {
    if (
      (project.status === "completed" ||
        project.status === "resource_shortage") &&
      project.aiRecommendations?.timeline_adjustments?.recommended_timeline
    ) {
      const timeline =
        project.aiRecommendations.timeline_adjustments.recommended_timeline;
      const match = timeline.match(/(\d+)\s*(weeks?|months?|days?)/i);

      if (match && project.processedAt) {
        const processedDate = new Date(project.processedAt);
        const duration = parseInt(match[1]);
        const unit = match[2].toLowerCase();

        let endDate = new Date(processedDate);
        if (unit.includes("day")) {
          endDate.setDate(endDate.getDate() + duration);
        } else if (unit.includes("week")) {
          endDate.setDate(endDate.getDate() + duration * 7);
        } else if (unit.includes("month")) {
          endDate.setMonth(endDate.getMonth() + duration);
        }

        if (now > endDate) {
          const result = deallocateProjectResources(project.id);
          expiredProjects.push(project.id);
          deallocations.push({
            projectId: project.id,
            title: project.originalInput.title,
            ...result,
          });

          updateMCPProjectStatus(project.id, "expired");

          // Generate completion report automatically
          generateProjectCompletionReport(project, result);
          reportsGenerated++;

          dataStorage.createAlert({
            alertType: "Project Timeline Expired",
            message: `Project "${project.originalInput.title || project.id}" timeline has ended. All resources have been deallocated.`,
            severity: "Low",
            projectId: project.id,
            isResolved: false,
          });
        }
      }
    }
  }

  return { expiredProjects, deallocations, reportsGenerated };
}

// Auto-check expired projects every 60 seconds
let autoCheckInterval: NodeJS.Timeout | null = null;

export function startAutoExpiryCheck(): void {
  if (autoCheckInterval) return;
  console.log(
    "[Auto Expiry] Starting automatic project expiry checker (every 60 seconds)",
  );
  autoCheckInterval = setInterval(() => {
    const result = checkAndDeallocateExpiredProjects();
    if (result.expiredProjects.length > 0) {
      console.log(
        `[Auto Expiry] Processed ${result.expiredProjects.length} expired projects, generated ${result.reportsGenerated} reports`,
      );
    }
  }, 60000);
}

export function stopAutoExpiryCheck(): void {
  if (autoCheckInterval) {
    clearInterval(autoCheckInterval);
    autoCheckInterval = null;
    console.log("[Auto Expiry] Stopped automatic project expiry checker");
  }
}

router.get("/api/mcp/projects", async (req: Request, res: Response) => {
  try {
    const projects = getAllMCPProjects();
    res.json(projects);
  } catch (error) {
    console.error("Failed to fetch MCP projects:", error);
    res.status(500).json({ error: "Failed to fetch MCP projects" });
  }
});

router.get("/api/mcp/projects/:id", async (req: Request, res: Response) => {
  try {
    const project = getMCPProjectById(req.params.id);
    if (!project) {
      return res.status(404).json({ error: "MCP project not found" });
    }
    res.json(project);
  } catch (error) {
    console.error("Failed to fetch MCP project:", error);
    res.status(500).json({ error: "Failed to fetch MCP project" });
  }
});

router.get("/api/mcp/stats", async (req: Request, res: Response) => {
  try {
    const stats = getProjectStats();
    res.json(stats);
  } catch (error) {
    console.error("Failed to fetch MCP stats:", error);
    res.status(500).json({ error: "Failed to fetch MCP stats" });
  }
});

router.post("/api/mcp/projects", async (req: Request, res: Response) => {
  try {
    const projectInput: MCPProjectInput = req.body;

    if (
      !projectInput.estimated_cost ||
      !projectInput.estimated_time_needed ||
      !projectInput.required_team ||
      !projectInput.required_resources ||
      !projectInput.complexity_level
    ) {
      return res.status(400).json({
        error:
          "Missing required fields: estimated_cost, estimated_time_needed, required_team, required_resources, complexity_level",
      });
    }

    const createdProject = createMCPProject(projectInput);

    updateMCPProjectStatus(createdProject.id, "processing");

    processProjectWithAI(createdProject.id, projectInput);

    res.status(201).json({
      message: "Project submitted for AI analysis",
      project: createdProject,
    });
  } catch (error: any) {
    console.error("Failed to create MCP project:", error);
    res
      .status(500)
      .json({ error: "Failed to create MCP project: " + error.message });
  }
});

async function processProjectWithAI(
  projectId: string,
  input: MCPProjectInput,
): Promise<void> {
  try {
    const { labs, resources, users } = getDataForAI();

    let recommendations: AIRecommendation;

    if (process.env["OPENAI_API_KEY"]) {
      try {
        recommendations = await analyzeProjectWithAI(
          input,
          labs,
          resources,
          users,
        );
      } catch (aiError) {
        console.error("AI analysis failed, using fallback:", aiError);
        recommendations = generateFallbackRecommendations(
          input,
          labs,
          resources,
          users,
        );
      }
    } else {
      console.log("No OpenAI API key, using fallback recommendations");
      recommendations = generateFallbackRecommendations(
        input,
        labs,
        resources,
        users,
      );
    }

    const { alerts, appliedTeam, appliedResources } = applyAllocation(
      projectId,
      recommendations,
    );

    const hasResourceShortage = alerts.some(
      (a) =>
        a.alertType === "Missing HR Resource" ||
        a.alertType === "HR Already Allocated" ||
        a.alertType === "Missing Resource" ||
        a.alertType === "Insufficient Resource",
    );

    (recommendations as any).allocation_result = {
      alerts_generated: alerts.length,
      team_allocated: appliedTeam,
      resources_allocated: appliedResources,
      has_resource_shortage: hasResourceShortage,
    };

    updateMCPProjectWithRecommendations(projectId, recommendations);

    if (hasResourceShortage) {
      updateMCPProjectResourceShortage(projectId, true);
    }
  } catch (error: any) {
    console.error("Failed to process project with AI:", error);
    updateMCPProjectStatus(projectId, "failed", error.message);
  }
}

router.post(
  "/api/mcp/projects/:id/reprocess",
  async (req: Request, res: Response) => {
    try {
      const project = getMCPProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "MCP project not found" });
      }

      deallocateProjectResources(project.id);

      updateMCPProjectStatus(project.id, "processing");

      processProjectWithAI(project.id, project.originalInput);

      res.json({ message: "Project resubmitted for AI analysis" });
    } catch (error: any) {
      console.error("Failed to reprocess MCP project:", error);
      res
        .status(500)
        .json({ error: "Failed to reprocess project: " + error.message });
    }
  },
);

router.post(
  "/api/mcp/projects/:id/deallocate",
  async (req: Request, res: Response) => {
    try {
      const project = getMCPProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "MCP project not found" });
      }

      const result = deallocateProjectResources(project.id);

      res.json({
        message: "Project resources deallocated successfully",
        ...result,
      });
    } catch (error: any) {
      console.error("Failed to deallocate project resources:", error);
      res
        .status(500)
        .json({ error: "Failed to deallocate resources: " + error.message });
    }
  },
);

router.delete("/api/mcp/projects/:id", async (req: Request, res: Response) => {
  try {
    deallocateProjectResources(req.params.id);

    const deleted = deleteMCPProject(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "MCP project not found" });
    }
    res.json({ message: "MCP project deleted successfully" });
  } catch (error) {
    console.error("Failed to delete MCP project:", error);
    res.status(500).json({ error: "Failed to delete MCP project" });
  }
});

router.get("/api/mcp/check-expired", async (req: Request, res: Response) => {
  try {
    const result = checkAndDeallocateExpiredProjects();
    res.json({
      message: "Expired projects checked",
      ...result,
    });
  } catch (error) {
    console.error("Failed to check expired projects:", error);
    res.status(500).json({ error: "Failed to check expired projects" });
  }
});

// Reports API
router.get("/api/reports", async (req: Request, res: Response) => {
  try {
    const reports = dataStorage.getAllReports();
    res.json(reports);
  } catch (error) {
    console.error("Failed to fetch reports:", error);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

router.get("/api/reports/:id", async (req: Request, res: Response) => {
  try {
    const report = dataStorage.getReportById(parseInt(req.params.id));
    if (!report) {
      return res.status(404).json({ error: "Report not found" });
    }
    res.json(report);
  } catch (error) {
    console.error("Failed to fetch report:", error);
    res.status(500).json({ error: "Failed to fetch report" });
  }
});

router.delete("/api/reports/:id", async (req: Request, res: Response) => {
  try {
    const deleted = dataStorage.deleteReport(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: "Report not found" });
    }
    res.json({ message: "Report deleted successfully" });
  } catch (error) {
    console.error("Failed to delete report:", error);
    res.status(500).json({ error: "Failed to delete report" });
  }
});

router.get("/api/agent/alerts", async (req: Request, res: Response) => {
  try {
    const alerts = dataStorage.getAlertsForAgent();

    const agentPayload = {
      timestamp: new Date().toISOString(),
      total_alerts: alerts.length,
      alerts: alerts.map((alert) => ({
        alert_id: alert.alertId,
        type: alert.alertType,
        message: alert.message,
        severity: alert.severity,
        project_id: alert.projectId,
        resource_id: alert.resourceId,
        created_at: alert.createdOn,
        action_required: getActionRequired(alert.alertType),
      })),
      api_endpoints: {
        resolve_alert: "POST /api/agent/alerts/{alert_id}/resolve",
        mark_sent: "POST /api/agent/alerts/{alert_id}/mark-sent",
        get_resource_details: "GET /api/resources/{resource_id}",
        get_user_details: "GET /api/users/{user_id}",
        get_project_details: "GET /api/mcp/projects/{project_id}",
      },
    };

    res.json(agentPayload);
  } catch (error) {
    console.error("Failed to fetch alerts for agent:", error);
    res.status(500).json({ error: "Failed to fetch alerts" });
  }
});

router.post(
  "/api/agent/alerts/:alertId/mark-sent",
  async (req: Request, res: Response) => {
    try {
      const alert = dataStorage.markAlertSentToAgent(
        parseInt(req.params.alertId),
      );
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json({ message: "Alert marked as sent to agent", alert });
    } catch (error) {
      console.error("Failed to mark alert as sent:", error);
      res.status(500).json({ error: "Failed to mark alert" });
    }
  },
);

router.post(
  "/api/agent/alerts/:alertId/resolve",
  async (req: Request, res: Response) => {
    try {
      const alert = dataStorage.resolveAlert(parseInt(req.params.alertId));
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json({ message: "Alert resolved", alert });
    } catch (error) {
      console.error("Failed to resolve alert:", error);
      res.status(500).json({ error: "Failed to resolve alert" });
    }
  },
);

router.get("/api/agent/status", async (req: Request, res: Response) => {
  try {
    const alerts = dataStorage.getAlertsForAgent();
    const unresolvedAlerts = dataStorage.getUnresolvedAlerts();
    const { labs, resources, users } = getDataForAI();

    const availableUsers = users.filter((u) => !u.isAllocated);
    const resourcesWithAvailability = resources.map((r) => ({
      ...r,
      isFullyAllocated: r.availableQuantity === 0,
    }));

    res.json({
      timestamp: new Date().toISOString(),
      pending_alerts_for_agent: alerts.length,
      total_unresolved_alerts: unresolvedAlerts.length,
      available_hr_count: availableUsers.length,
      total_hr_count: users.length,
      resources_summary: {
        total: resources.length,
        fully_available: resourcesWithAvailability.filter(
          (r) => r.allocatedQuantity === 0,
        ).length,
        partially_allocated: resourcesWithAvailability.filter(
          (r) => r.allocatedQuantity > 0 && r.availableQuantity > 0,
        ).length,
        fully_allocated: resourcesWithAvailability.filter(
          (r) => r.isFullyAllocated,
        ).length,
      },
      labs_count: labs.length,
    });
  } catch (error) {
    console.error("Failed to fetch agent status:", error);
    res.status(500).json({ error: "Failed to fetch status" });
  }
});

function getActionRequired(alertType: string): string {
  const actions: Record<string, string> = {
    "Missing HR Resource":
      "Find and onboard a team member with the required skills or reallocate existing resources",
    "HR Already Allocated":
      "Wait for the team member to become available or find an alternative",
    "Missing Resource": "Procure the required resource or find alternatives",
    "Insufficient Resource":
      "Procure additional units or adjust project requirements",
    "Project Timeline Expired":
      "Review project status and clean up any remaining allocations",
  };
  return actions[alertType] || "Review and take appropriate action";
}

// API to send missing resources/HR to external agent
router.post(
  "/api/agent/send-resource-request",
  async (req: Request, res: Response) => {
    try {
      const unresolvedAlerts = dataStorage.getUnresolvedAlerts();

      const alertsToMark: number[] = [];

      const resourceRequests = unresolvedAlerts
        .filter(
          (alert) =>
            alert.alertType === "Missing HR Resource" ||
            alert.alertType === "Missing Resource" ||
            alert.alertType === "HR Already Allocated" ||
            alert.alertType === "Insufficient Resource",
        )
        .map((alert) => {
          let resourceNeeded = "";
          let type = "";

          if (
            alert.alertType === "Missing HR Resource" ||
            alert.alertType === "HR Already Allocated"
          ) {
            type = "HR";
            const roleMatch = alert.message?.match(/role "([^"]+)"/);
            resourceNeeded = roleMatch ? roleMatch[1] : "Unknown Role";
          } else {
            type = "Resource";
            const resourceMatch =
              alert.message?.match(/resource "([^"]+)"/i) ||
              alert.message?.match(/"([^"]+)"/);
            resourceNeeded = resourceMatch
              ? resourceMatch[1]
              : "Unknown Resource";
          }

          alertsToMark.push(alert.alertId);

          return {
            resource_needed: resourceNeeded,
            type,
            date: alert.createdOn,
          };
        });

      // Simplified payload format for external agent - only resource needed and type
      const agentPayload = {
        requests: resourceRequests,
      };

      // Mark alerts as sent to agent
      for (const alertId of alertsToMark) {
        dataStorage.markAlertSentToAgent(alertId);
      }

      res.json(agentPayload);
    } catch (error) {
      console.error("Failed to send resource request:", error);
      res.status(500).json({ error: "Failed to send resource request" });
    }
  },
);

// API for external agent to notify when resource is fulfilled
router.post(
  "/api/agent/resource-fulfilled",
  async (req: Request, res: Response) => {
    try {
      const { alert_id, fulfilled_by, notes } = req.body;

      if (!alert_id) {
        return res.status(400).json({ error: "alert_id is required" });
      }

      const alert = dataStorage.resolveAlert(alert_id);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }

      // Create a resolution log
      dataStorage.createAlert({
        alertType: "Resource Fulfilled",
        message: `Resource request fulfilled by ${fulfilled_by || "external agent"}. Notes: ${notes || "N/A"}`,
        severity: "Low",
        projectId: alert.projectId,
        isResolved: true,
      });

      res.json({
        message: "Resource fulfillment recorded",
        original_alert: alert,
        fulfilled_by,
        notes,
      });
    } catch (error) {
      console.error("Failed to record resource fulfillment:", error);
      res.status(500).json({ error: "Failed to record fulfillment" });
    }
  },
);

// Generate project completion report
router.get(
  "/api/mcp/projects/:id/report",
  async (req: Request, res: Response) => {
    try {
      const project = getMCPProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "MCP project not found" });
      }

      const teamMembers = dataStorage.getProjectTeamMembersByProjectId(
        project.id,
      );
      const projectResources = dataStorage.getProjectResourcesByProjectId(
        project.id,
      );
      const projectAlerts = dataStorage
        .getAllAlerts()
        .filter((a) => a.projectId === project.id);

      // Calculate project timeline status
      let timelineStatus = "In Progress";
      let daysRemaining = null;
      let isExpired = false;

      if (
        project.processedAt &&
        project.aiRecommendations?.timeline_adjustments?.recommended_timeline
      ) {
        const timeline =
          project.aiRecommendations.timeline_adjustments.recommended_timeline;
        const match = timeline.match(/(\d+)\s*(weeks?|months?|days?)/i);

        if (match) {
          const processedDate = new Date(project.processedAt);
          const duration = parseInt(match[1]);
          const unit = match[2].toLowerCase();

          let endDate = new Date(processedDate);
          if (unit.includes("day")) {
            endDate.setDate(endDate.getDate() + duration);
          } else if (unit.includes("week")) {
            endDate.setDate(endDate.getDate() + duration * 7);
          } else if (unit.includes("month")) {
            endDate.setMonth(endDate.getMonth() + duration);
          }

          const now = new Date();
          if (now > endDate) {
            timelineStatus = "Completed/Expired";
            isExpired = true;
            daysRemaining = 0;
          } else {
            const diffTime = endDate.getTime() - now.getTime();
            daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            timelineStatus = `${daysRemaining} days remaining`;
          }
        }
      }

      // Get user details for team members
      const teamDetails = teamMembers.map((tm) => {
        const user = dataStorage.getUserById(tm.userId);
        return {
          userId: tm.userId,
          name: user?.name || "Unknown",
          role: tm.role,
          email: user?.email,
        };
      });

      // Get resource details
      const resourceDetails = projectResources.map((pr) => {
        const resource = dataStorage.getResourceById(pr.resourceId);
        const lab = resource?.labId
          ? dataStorage.getLabById(resource.labId)
          : null;
        return {
          resourceId: pr.resourceId,
          name: resource?.name || "Unknown",
          category: resource?.category,
          allocatedQuantity: pr.allocatedQuantity,
          labName: lab?.labName,
        };
      });

      const report = {
        report_generated_at: new Date().toISOString(),
        project: {
          id: project.id,
          title: project.originalInput.title || "Untitled Project",
          description: project.originalInput.description,
          status: project.status,
          complexity_level: project.originalInput.complexity_level,
          submitted_at: project.originalInput.submittedAt,
          processed_at: project.processedAt,
        },
        timeline: {
          original_timeline:
            project.aiRecommendations?.timeline_adjustments?.original_timeline,
          recommended_timeline:
            project.aiRecommendations?.timeline_adjustments
              ?.recommended_timeline,
          status: timelineStatus,
          days_remaining: daysRemaining,
          is_expired: isExpired,
          milestones:
            project.aiRecommendations?.timeline_adjustments?.milestones || [],
        },
        budget: {
          original_cost: project.originalInput.estimated_cost,
          optimized_cost:
            project.aiRecommendations?.budget_optimization?.optimized_cost,
          savings_percentage:
            project.aiRecommendations?.budget_optimization?.savings_percentage,
          optimization_tips:
            project.aiRecommendations?.budget_optimization?.optimization_tips ||
            [],
        },
        team_allocation: {
          required_roles: project.originalInput.required_team,
          allocated_members: teamDetails,
          total_allocated: teamDetails.length,
          total_required: project.originalInput.required_team.length,
          allocation_complete:
            teamDetails.length >= project.originalInput.required_team.length,
        },
        resource_allocation: {
          required_resources: project.originalInput.required_resources,
          allocated_resources: resourceDetails,
          total_allocated: resourceDetails.length,
          total_required: project.originalInput.required_resources.length,
          allocation_complete:
            resourceDetails.length >=
            project.originalInput.required_resources.length,
        },
        risk_assessment: project.aiRecommendations?.risk_assessment || {},
        alerts_summary: {
          total_alerts: projectAlerts.length,
          resolved: projectAlerts.filter((a) => a.isResolved).length,
          unresolved: projectAlerts.filter((a) => !a.isResolved).length,
          by_type: projectAlerts.reduce((acc: Record<string, number>, a) => {
            acc[a.alertType] = (acc[a.alertType] || 0) + 1;
            return acc;
          }, {}),
        },
        overall_recommendations:
          project.aiRecommendations?.overall_recommendations || [],
        confidence_score: project.aiRecommendations?.confidence_score,
      };

      res.json(report);
    } catch (error) {
      console.error("Failed to generate project report:", error);
      res.status(500).json({ error: "Failed to generate report" });
    }
  },
);

// Check expired projects and generate reports
router.get(
  "/api/mcp/expired-projects-reports",
  async (req: Request, res: Response) => {
    try {
      const now = new Date();
      const mcpProjects = getAllMCPProjects();
      const expiredReports: any[] = [];

      for (const project of mcpProjects) {
        if (
          project.status === "completed" &&
          project.aiRecommendations?.timeline_adjustments?.recommended_timeline
        ) {
          const timeline =
            project.aiRecommendations.timeline_adjustments.recommended_timeline;
          const match = timeline.match(/(\d+)\s*(weeks?|months?|days?)/i);

          if (match && project.processedAt) {
            const processedDate = new Date(project.processedAt);
            const duration = parseInt(match[1]);
            const unit = match[2].toLowerCase();

            let endDate = new Date(processedDate);
            if (unit.includes("day")) {
              endDate.setDate(endDate.getDate() + duration);
            } else if (unit.includes("week")) {
              endDate.setDate(endDate.getDate() + duration * 7);
            } else if (unit.includes("month")) {
              endDate.setMonth(endDate.getMonth() + duration);
            }

            if (now > endDate) {
              const teamMembers = dataStorage.getProjectTeamMembersByProjectId(
                project.id,
              );
              const projectResources =
                dataStorage.getProjectResourcesByProjectId(project.id);

              expiredReports.push({
                project_id: project.id,
                title: project.originalInput.title || "Untitled",
                started_at: project.processedAt,
                ended_at: endDate.toISOString(),
                days_overdue: Math.ceil(
                  (now.getTime() - endDate.getTime()) / (1000 * 60 * 60 * 24),
                ),
                team_count: teamMembers.length,
                resources_count: projectResources.length,
                original_cost: project.originalInput.estimated_cost,
                optimized_cost:
                  project.aiRecommendations?.budget_optimization
                    ?.optimized_cost,
                complexity: project.originalInput.complexity_level,
              });
            }
          }
        }
      }

      res.json({
        generated_at: new Date().toISOString(),
        total_expired: expiredReports.length,
        expired_projects: expiredReports,
      });
    } catch (error) {
      console.error("Failed to generate expired projects reports:", error);
      res.status(500).json({ error: "Failed to generate reports" });
    }
  },
);

export default router;

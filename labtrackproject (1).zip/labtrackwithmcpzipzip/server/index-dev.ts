import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "url";
import http from "node:http";
import { createServer as createViteServer, createLogger } from "vite";
import { createApp } from "./app";
import viteConfig from "../vite.config";
import { startAutoExpiryCheck } from "./mcpRoutes";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = createApp();
const port = 5000;
const viteLogger = createLogger();

const setupVite = async (server: http.Server) => {
  const serverOptions = {
    middlewareMode: true,
    hmr: { 
      server,
      protocol: "wss",
      host: undefined,
      port: undefined,
    },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg: any, options: any) => {
        viteLogger.error(msg, options);
        process.exit(1);
      },
    },
    server: serverOptions,
    appType: "custom",
  });

  // Use vite middleware for assets and hot module replacement
  app.use(vite.middlewares);

  // Serve index.html for any unmatched route (SPA fallback)
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(__dirname, "..", "client", "index.html");
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
};

(async () => {
  const server = http.createServer(app);
  await setupVite(server);

  server.listen(port, "0.0.0.0", () => {
    console.log(`[express] serving on port ${port}`);
    // Start automatic project expiry checker
    startAutoExpiryCheck();
  });
})();

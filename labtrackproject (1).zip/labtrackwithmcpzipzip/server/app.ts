import express, { type Express } from "express";
import session from "express-session";
import routes from "./routes";
import mcpRoutes from "./mcpRoutes";

export function createApp(): Express {
  const app = express();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  // Session configuration
  app.use(
    session({
      secret: "labtrack-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false, // Set to true if using HTTPS
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Routes
  app.use(routes);
  app.use(mcpRoutes);

  return app;
}

export default createApp;

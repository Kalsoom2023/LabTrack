import path from "node:path";
import { fileURLToPath } from "url";
import { createApp } from "./app";
import { startAutoExpiryCheck } from "./mcpRoutes";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = createApp();
const port = 5000;

// Serve static files from built frontend
app.use("/", (req, res, next) => {
  // Serve static assets
  if (
    req.path.startsWith("/src/") ||
    req.path.startsWith("/assets/") ||
    req.path.endsWith(".js") ||
    req.path.endsWith(".css") ||
    req.path.endsWith(".png") ||
    req.path.endsWith(".jpg") ||
    req.path.endsWith(".svg")
  ) {
    res.sendFile(path.join(__dirname, "../dist/public", req.path));
  } else {
    // Serve index.html for SPA routing
    res.sendFile(path.join(__dirname, "../dist/public/index.html"));
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`[express] serving on port ${port}`);
  startAutoExpiryCheck();
});

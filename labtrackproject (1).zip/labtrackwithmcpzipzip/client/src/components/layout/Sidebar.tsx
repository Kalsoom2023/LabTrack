import { Link, useLocation } from "wouter";
import { NAV_ITEMS } from "@/lib/mockData";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth";
import { LogOut } from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  // Role-based navigation filtering
  const filteredNavItems = NAV_ITEMS.filter(item => {
    if (!user) return false;
    
    // Manager and Admin see everything
    if (user.role === "Manager" || user.role === "Administrator") return true;
    
    // Technician sees Inventory, Alerts, Reports, Labs
    if (user.role === "Technician") {
      return ["/inventory", "/alerts", "/reports", "/labs"].includes(item.href);
    }
    
    // Assistant sees Reservations, Labs, Dashboard
    if (user.role === "Assistant") {
      return ["/", "/reservations", "/labs"].includes(item.href);
    }
    
    // Faculty/Student sees Labs, Reservations (View only mostly)
    return ["/", "/labs", "/reservations"].includes(item.href);
  });

  if (!user) return null;

  return (
    <div className="flex h-full w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center gap-3 px-6 border-b border-sidebar-border">
        <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
          <span className="text-xs font-bold text-white">LT</span>
        </div>
        <span className="font-display text-xl font-bold tracking-tight">LabTrack</span>
      </div>
      
      <div className="flex-1 overflow-y-auto py-6 px-4">
        <nav className="space-y-1">
          {filteredNavItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex cursor-pointer items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    isActive 
                      ? "bg-sidebar-primary text-sidebar-primary-foreground" 
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
      
      <div className="border-t border-sidebar-border p-4">
        <div className="flex items-center justify-between gap-3 rounded-lg bg-sidebar-accent/50 p-3">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-sidebar-primary/20 flex items-center justify-center text-xs font-bold text-sidebar-primary uppercase">
              {user.username.substring(0, 2)}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium truncate max-w-[80px]">{user.name}</span>
              <span className="text-xs text-sidebar-foreground/60">{user.role}</span>
            </div>
          </div>
          <button 
            onClick={logout}
            className="text-sidebar-foreground/50 hover:text-sidebar-foreground transition-colors"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

import { 
  LayoutDashboard, 
  Monitor, 
  CalendarDays, 
  Users, 
  ClipboardList, 
  AlertCircle, 
  Settings, 
  Box,
  Building2,
  History
} from "lucide-react";

export interface User {
  user_id: number;
  name: string;
  role: string;
  email: string;
  username: string;
  avatar?: string;
}

export interface Lab {
  lab_id: number;
  lab_name: string;
  location: string;
  incharge_name: string;
  lab_capacity: number;
  open_time: string;
  close_time: string;
  maintenance_day: string;
  status: "Open" | "Closed" | "Maintenance";
}

export interface ResourceCategory {
  category_id: number;
  name: string;
  description: string;
}

export interface Resource {
  resource_id: number;
  lab_id: number;
  category_id: number;
  name: string;
  category: string;
  quantity: number;
  status: "Available" | "In Use" | "Maintenance" | "Defective";
  threshold_level: number;
  warranty_expiry: string;
  image?: string;
}

export interface Reservation {
  reservation_id: number;
  resource_id: number;
  lab_id: number;
  user_id: number;
  start_time: string;
  end_time: string;
  purpose: string;
  approved_by?: string;
  status: "Pending" | "Approved" | "Rejected" | "Completed";
}

export interface Alert {
  alert_id: number;
  resource_id: number;
  alert_type: string;
  created_on: string;
  is_resolved: boolean;
  severity: "High" | "Medium" | "Low";
}

// Mock Data
export const USERS: User[] = [
  { user_id: 1, name: "Ali Raza", role: "Manager", email: "ali@university.com", username: "ali01" },
  { user_id: 2, name: "Sara Khan", role: "Assistant", email: "sara@university.com", username: "sara_k" },
  { user_id: 3, name: "John Smith", role: "Technician", email: "john@university.com", username: "john_s" },
  { user_id: 4, name: "Ayesha Malik", role: "Administrator", email: "ayesha@university.com", username: "ayeshaM" },
  // Filling in missing users referenced in logs
  { user_id: 5, name: "Kamran", role: "Faculty", email: "kamran@university.com", username: "kamran" },
  { user_id: 6, name: "Rabia", role: "Faculty", email: "rabia@university.com", username: "rabia" },
  { user_id: 7, name: "Farah", role: "Faculty", email: "farah@university.com", username: "farah" }
];

export const LABS: Lab[] = [
  { 
    lab_id: 1, 
    lab_name: "Computer Lab 1", 
    location: "Block E - Room 501", 
    incharge_name: "Sir Usman", 
    lab_capacity: 50, 
    open_time: "09:00", 
    close_time: "18:00", 
    maintenance_day: "Monday",
    status: "Open"
  },
  { 
    lab_id: 2, 
    lab_name: "Computer Lab 2", 
    location: "Block E - Room 502", 
    incharge_name: "Miss Aisha", 
    lab_capacity: 45, 
    open_time: "09:00", 
    close_time: "17:00", 
    maintenance_day: "Tuesday",
    status: "Open"
  },
  { 
    lab_id: 3, 
    lab_name: "Networking Lab", 
    location: "Block F - Room 301", 
    incharge_name: "Engr. Hassan", 
    lab_capacity: 35, 
    open_time: "08:30", 
    close_time: "16:00", 
    maintenance_day: "Wednesday",
    status: "Open"
  },
  { 
    lab_id: 4, 
    lab_name: "AI & Machine Learning Lab", 
    location: "Block G - Room 210", 
    incharge_name: "Dr. Adeel", 
    lab_capacity: 40, 
    open_time: "09:00", 
    close_time: "18:00", 
    maintenance_day: "Thursday",
    status: "Open"
  },
  { 
    lab_id: 5, 
    lab_name: "Cyber Security Lab", 
    location: "Block F - Room 305", 
    incharge_name: "Sir Kamran", 
    lab_capacity: 30, 
    open_time: "10:00", 
    close_time: "16:00", 
    maintenance_day: "Friday",
    status: "Open"
  },
  { 
    lab_id: 6, 
    lab_name: "Software Engineering Lab", 
    location: "Block E - Room 503", 
    incharge_name: "Miss Rabia", 
    lab_capacity: 55, 
    open_time: "08:00", 
    close_time: "15:00", 
    maintenance_day: "Saturday",
    status: "Open"
  },
  { 
    lab_id: 7, 
    lab_name: "Data Science Lab", 
    location: "Block G - Room 211", 
    incharge_name: "Dr. Farah", 
    lab_capacity: 60, 
    open_time: "09:00", 
    close_time: "17:00", 
    maintenance_day: "Sunday",
    status: "Open"
  },
];

export const CATEGORIES: ResourceCategory[] = [
  { category_id: 1, name: "Desktop PCs", description: "High-performance computers for students" },
  { category_id: 2, name: "Laptops", description: "Portable computing systems" },
  { category_id: 3, name: "Networking Devices", description: "Routers, switches, access points" },
  { category_id: 4, name: "Servers", description: "Backend computing machines" },
  { category_id: 5, name: "Monitors", description: "LCD / LED display screens" },
  { category_id: 6, name: "Input Devices", description: "Keyboards, mice, scanners" },
  { category_id: 7, name: "Accessories", description: "Cables, headphones, adapters" },
];

export const RESOURCES: Resource[] = [
  { resource_id: 1, lab_id: 1, category_id: 1, name: "Dell OptiPlex Desktop PC", category: "Desktop PCs", quantity: 20, status: "Available", threshold_level: 5, warranty_expiry: "2028-05-10" },
  { resource_id: 2, lab_id: 2, category_id: 2, name: "HP EliteBook Laptop", category: "Laptops", quantity: 15, status: "Available", threshold_level: 3, warranty_expiry: "2027-11-01" },
  { resource_id: 3, lab_id: 3, category_id: 3, name: "Cisco Switch 2960", category: "Networking Devices", quantity: 6, status: "Available", threshold_level: 1, warranty_expiry: "2029-03-20" },
  { resource_id: 4, lab_id: 4, category_id: 4, name: "Dell PowerEdge Server", category: "Servers", quantity: 3, status: "Available", threshold_level: 1, warranty_expiry: "2030-01-15" },
  { resource_id: 5, lab_id: 5, category_id: 5, name: "Samsung 24-inch Monitor", category: "Monitors", quantity: 30, status: "Available", threshold_level: 5, warranty_expiry: "2031-08-01" },
  { resource_id: 6, lab_id: 6, category_id: 6, name: "Logitech Keyboard and Mouse Set", category: "Input Devices", quantity: 40, status: "Available", threshold_level: 10, warranty_expiry: "2032-06-11" },
  { resource_id: 7, lab_id: 7, category_id: 7, name: "HDMI Cable Set", category: "Accessories", quantity: 50, status: "Available", threshold_level: 15, warranty_expiry: "2033-12-30" },
];

export const ALERTS: Alert[] = [
  { alert_id: 1, resource_id: 1, alert_type: "Low PC availability", created_on: "2024-05-20", is_resolved: false, severity: "High" },
  { alert_id: 2, resource_id: 2, alert_type: "Laptop warranty expiring soon", created_on: "2024-05-18", is_resolved: true, severity: "Medium" },
  { alert_id: 3, resource_id: 3, alert_type: "Network switch overheating", created_on: "2024-05-12", is_resolved: false, severity: "High" },
  { alert_id: 4, resource_id: 4, alert_type: "Server storage nearly full", created_on: "2024-05-10", is_resolved: false, severity: "Medium" },
  { alert_id: 5, resource_id: 5, alert_type: "Monitor display flickering", created_on: "2024-05-05", is_resolved: false, severity: "Low" },
  { alert_id: 6, resource_id: 6, alert_type: "Keyboard malfunction detected", created_on: "2024-05-03", is_resolved: true, severity: "Low" },
  { alert_id: 7, resource_id: 7, alert_type: "Broken HDMI cable reported", created_on: "2024-05-01", is_resolved: false, severity: "Low" },
];

export const RESERVATIONS: Reservation[] = [
  { reservation_id: 1, resource_id: 1, lab_id: 1, user_id: 1, start_time: "2024-06-01T10:00:00", end_time: "2024-06-01T12:00:00", purpose: "PC use for coding test", approved_by: "Sara Khan", status: "Approved" },
  { reservation_id: 2, resource_id: 2, lab_id: 2, user_id: 2, start_time: "2024-06-05T09:30:00", end_time: "2024-06-05T11:00:00", purpose: "Laptop borrowing for ML project", approved_by: "Aisha", status: "Approved" },
  { reservation_id: 3, resource_id: 3, lab_id: 3, user_id: 3, start_time: "2024-06-03T14:00:00", end_time: "2024-06-03T15:00:00", purpose: "Network switch configuration", approved_by: "Hassan", status: "Approved" },
  { reservation_id: 4, resource_id: 4, lab_id: 4, user_id: 4, start_time: "2024-06-02T08:30:00", end_time: "2024-06-02T10:00:00", purpose: "Server load testing", approved_by: "Adeel", status: "Approved" },
  { reservation_id: 5, resource_id: 5, lab_id: 5, user_id: 5, start_time: "2024-06-07T12:00:00", end_time: "2024-06-07T14:30:00", purpose: "Monitor usage for cybersecurity class", approved_by: "Kamran", status: "Approved" },
  { reservation_id: 6, resource_id: 6, lab_id: 6, user_id: 6, start_time: "2024-06-08T11:00:00", end_time: "2024-06-08T13:00:00", purpose: "Keyboard setup testing", approved_by: "Rabia", status: "Approved" },
  { reservation_id: 7, resource_id: 7, lab_id: 7, user_id: 7, start_time: "2024-06-10T09:00:00", end_time: "2024-06-10T10:00:00", purpose: "HDMI cable testing for smart screens", approved_by: "Farah", status: "Approved" },
];

export const NAV_ITEMS = [
  { label: "Dashboard", icon: LayoutDashboard, href: "/" },
  { label: "Labs", icon: Building2, href: "/labs" },
  { label: "Inventory", icon: Box, href: "/inventory" },
  { label: "Reservations", icon: CalendarDays, href: "/reservations" },
  { label: "Projects", icon: ClipboardList, href: "/projects" },
  { label: "Users", icon: Users, href: "/users" },
  { label: "Reports", icon: History, href: "/reports" },
  { label: "Alerts", icon: AlertCircle, href: "/alerts" },
];

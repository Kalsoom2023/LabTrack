import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Clock, MapPin, User, Calendar, Monitor, Plus, Edit2, Trash2, X, ChevronDown, ChevronUp } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";

interface Lab {
  labId: number;
  labName: string;
  location: string;
  inchargeName: string;
  labCapacity: number;
  usedCapacity?: number;
  openTime: string;
  closeTime: string;
  maintenanceDay: string;
}

export default function Labs() {
  const { user } = useAuth();
  const [labs, setLabs] = useState<Lab[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingLab, setEditingLab] = useState<Lab | null>(null);
  const [expandedLab, setExpandedLab] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    labName: "",
    location: "",
    inchargeName: "",
    labCapacity: 0,
    openTime: "09:00",
    closeTime: "17:00",
    maintenanceDay: "Monday",
  });

  useEffect(() => {
    fetchLabs();
  }, []);

  const fetchLabs = async () => {
    try {
      const res = await fetch("/api/labs");
      const data = await res.json();
      setLabs(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch labs:", error);
      setLabs([]);
    }
  };

  const handleSubmit = async () => {
    try {
      const method = editingLab ? "PUT" : "POST";
      const url = editingLab ? `/api/labs/${editingLab.labId}` : "/api/labs";
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        fetchLabs();
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save lab:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this lab?")) return;
    
    try {
      const res = await fetch(`/api/labs/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchLabs();
      }
    } catch (error) {
      console.error("Failed to delete lab:", error);
    }
  };

  const handleEdit = (lab: Lab) => {
    setEditingLab(lab);
    setFormData({
      labName: lab.labName,
      location: lab.location,
      inchargeName: lab.inchargeName,
      labCapacity: lab.labCapacity,
      openTime: lab.openTime,
      closeTime: lab.closeTime,
      maintenanceDay: lab.maintenanceDay,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingLab(null);
    setFormData({
      labName: "",
      location: "",
      inchargeName: "",
      labCapacity: 0,
      openTime: "09:00",
      closeTime: "17:00",
      maintenanceDay: "Monday",
    });
  };

  const isAdmin = user?.role === "Administrator" || user?.role === "Manager";

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Computer Labs</h1>
            <p className="text-muted-foreground mt-2">Manage and view all computer laboratory facilities.</p>
          </div>
          {isAdmin && (
            <Button 
              className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all duration-200" 
              onClick={() => { setShowForm(true); setEditingLab(null); }} 
              data-testid="button-create-lab"
            >
              <Plus className="h-4 w-4" /> Add Lab
            </Button>
          )}
        </div>

        {showForm && (
          <Card className="shadow-lg border-2 border-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
            <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
              <CardTitle>{editingLab ? "Edit Lab" : "Create New Lab"}</CardTitle>
              <Button variant="ghost" size="sm" onClick={resetForm} className="hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <Input
                placeholder="Lab Name"
                value={formData.labName}
                onChange={(e) => setFormData({ ...formData, labName: e.target.value })}
                className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                data-testid="input-labName"
              />
              <Input
                placeholder="Location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                data-testid="input-location"
              />
              <Input
                placeholder="In-Charge Name"
                value={formData.inchargeName}
                onChange={(e) => setFormData({ ...formData, inchargeName: e.target.value })}
                className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                data-testid="input-inchargeName"
              />
              <Input
                type="number"
                placeholder="Lab Capacity"
                value={formData.labCapacity}
                onChange={(e) => setFormData({ ...formData, labCapacity: parseInt(e.target.value) })}
                className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                data-testid="input-labCapacity"
              />
              <div className="grid grid-cols-2 gap-4">
                <Input
                  type="time"
                  value={formData.openTime}
                  onChange={(e) => setFormData({ ...formData, openTime: e.target.value })}
                  className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                  data-testid="input-openTime"
                />
                <Input
                  type="time"
                  value={formData.closeTime}
                  onChange={(e) => setFormData({ ...formData, closeTime: e.target.value })}
                  className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                  data-testid="input-closeTime"
                />
              </div>
              <Input
                placeholder="Maintenance Day"
                value={formData.maintenanceDay}
                onChange={(e) => setFormData({ ...formData, maintenanceDay: e.target.value })}
                className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 hover:border-purple-300 transition-colors"
                data-testid="input-maintenanceDay"
              />
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSubmit} className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white hover:shadow-lg transition-all duration-200" data-testid="button-save-lab">
                  {editingLab ? "Update Lab" : "Create Lab"}
                </Button>
                <Button onClick={resetForm} variant="outline" className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" data-testid="button-cancel">Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4">
          {labs.map((lab) => (
            <Card key={lab.labId} className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 group" data-testid={`card-lab-${lab.labId}`}>
              <div className="h-1 bg-gradient-to-r from-purple-500 to-pink-500" />
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <CardTitle className="group-hover:text-purple-600 transition-colors" data-testid={`text-labName-${lab.labId}`}>{lab.labName}</CardTitle>
                    <CardDescription className="flex items-center gap-1 mt-2 group-hover:text-purple-600 transition-colors">
                      <MapPin className="h-3.5 w-3.5" />
                      {lab.location}
                    </CardDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setExpandedLab(
                        expandedLab === lab.labId ? null : lab.labId
                      )
                    }
                    className="hover:bg-purple-100 dark:hover:bg-purple-900"
                    data-testid={`button-details-${lab.labId}`}
                  >
                    {expandedLab === lab.labId ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardHeader>

              {expandedLab === lab.labId && (
                <CardContent className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex flex-col gap-1 p-3 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30">
                      <span className="text-muted-foreground flex items-center gap-1.5 text-xs">
                        <User className="h-3.5 w-3.5" /> In-Charge
                      </span>
                      <span className="font-semibold text-gray-900 dark:text-gray-100" data-testid={`text-incharge-${lab.labId}`}>{lab.inchargeName}</span>
                    </div>
                    <div className="flex flex-col gap-1 p-3 rounded-lg bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/30 dark:to-cyan-900/30">
                      <span className="text-muted-foreground flex items-center gap-1.5 text-xs">
                        <Monitor className="h-3.5 w-3.5" /> Capacity
                      </span>
                      <div className="flex flex-col gap-1">
                        <span className="font-semibold text-gray-900 dark:text-gray-100" data-testid={`text-capacity-${lab.labId}`}>
                          {lab.labCapacity - (lab.usedCapacity || 0)} / {lab.labCapacity} available
                        </span>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${((lab.usedCapacity || 0) / lab.labCapacity) > 0.8 ? 'bg-red-500' : ((lab.usedCapacity || 0) / lab.labCapacity) > 0.5 ? 'bg-yellow-500' : 'bg-green-500'}`}
                            style={{ width: `${((lab.usedCapacity || 0) / lab.labCapacity) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1 p-3 rounded-lg bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/30 dark:to-red-900/30">
                      <span className="text-muted-foreground flex items-center gap-1.5 text-xs">
                        <Clock className="h-3.5 w-3.5" /> Hours
                      </span>
                      <span className="font-semibold text-gray-900 dark:text-gray-100">{lab.openTime} - {lab.closeTime}</span>
                    </div>
                    <div className="flex flex-col gap-1 p-3 rounded-lg bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30">
                      <span className="text-muted-foreground flex items-center gap-1.5 text-xs">
                        <Calendar className="h-3.5 w-3.5" /> Maintenance
                      </span>
                      <span className="font-semibold text-gray-900 dark:text-gray-100">{lab.maintenanceDay}</span>
                    </div>
                  </div>

                  {isAdmin && (
                    <div className="flex gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 gap-1 hover:bg-purple-100 dark:hover:bg-purple-900 hover:text-purple-700 dark:hover:text-purple-300 hover:border-purple-400 transition-all duration-200"
                        onClick={() => handleEdit(lab)}
                        data-testid={`button-edit-lab-${lab.labId}`}
                      >
                        <Edit2 className="h-4 w-4" /> Edit
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900 hover:border-red-400 transition-all duration-200"
                        onClick={() => handleDelete(lab.labId)}
                        data-testid={`button-delete-lab-${lab.labId}`}
                      >
                        <Trash2 className="h-4 w-4" /> Delete
                      </Button>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}

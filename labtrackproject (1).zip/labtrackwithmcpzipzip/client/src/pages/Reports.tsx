import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Download, BarChart3, Eye, Trash2, FileText } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface Report {
  reportId: number;
  title: string;
  type: string;
  projectId?: string;
  dateCreated: string;
  status: string;
  data: any;
}

export default function Reports() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const res = await fetch("/api/reports");
      if (res.ok) {
        const data = await res.json();
        setReports(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error("Failed to fetch reports:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (reportId: number) => {
    if (!confirm("Are you sure you want to delete this report?")) return;
    
    try {
      const res = await fetch(`/api/reports/${reportId}`, { method: "DELETE" });
      if (res.ok) {
        setReports(reports.filter(r => r.reportId !== reportId));
        toast({ title: "Report deleted" });
      }
    } catch (error) {
      toast({ title: "Failed to delete report", variant: "destructive" });
    }
  };

  const handleViewDetail = (report: Report) => {
    setSelectedReport(report);
    setShowDetailDialog(true);
  };

  const handleDownload = (report: Report) => {
    const dataStr = JSON.stringify(report.data, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${report.title.replace(/\s+/g, "_")}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Report downloaded" });
  };

  const filtered = reports.filter(r => 
    typeFilter === "all" || r.type === typeFilter
  );

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Project Completion": return "bg-green-100 text-green-800";
      case "Resource Utilization": return "bg-blue-100 text-blue-800";
      case "Lab Capacity": return "bg-purple-100 text-purple-800";
      case "Inventory": return "bg-orange-100 text-orange-800";
      case "Users": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    return status === "Ready" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800";
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading reports...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
            <p className="text-muted-foreground mt-1">View auto-generated project completion reports.</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{reports.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Project Completions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{reports.filter(r => r.type === "Project Completion").length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Ready Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-blue-600">{reports.filter(r => r.status === "Ready").length}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-3 py-2 border rounded-md bg-muted/50"
                data-testid="select-type-filter"
              >
                <option value="all">All Report Types</option>
                <option value="Project Completion">Project Completion</option>
                <option value="Resource Utilization">Resource Utilization</option>
                <option value="Lab Capacity">Lab Capacity</option>
                <option value="Inventory">Inventory</option>
                <option value="Users">Users</option>
              </select>
            </div>
          </CardHeader>
          <CardContent>
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">No reports yet</p>
                <p className="text-sm mt-1">Reports are automatically generated when project timelines end.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map(report => (
                  <div key={report.reportId} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors" data-testid={`card-report-${report.reportId}`}>
                    <div className="flex-1">
                      <h3 className="font-medium" data-testid={`text-title-${report.reportId}`}>{report.title}</h3>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        <Badge className={getTypeColor(report.type)} data-testid={`badge-type-${report.reportId}`}>{report.type}</Badge>
                        <Badge className={getStatusColor(report.status)} data-testid={`badge-status-${report.reportId}`}>{report.status}</Badge>
                        {report.projectId && (
                          <span className="text-xs text-muted-foreground bg-gray-100 px-2 py-0.5 rounded">
                            Project: {report.projectId.substring(0, 15)}...
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Created: {new Date(report.dateCreated).toLocaleString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="gap-2" onClick={() => handleViewDetail(report)} data-testid={`button-view-${report.reportId}`}>
                        <Eye className="h-4 w-4" /> View
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2" onClick={() => handleDownload(report)} data-testid={`button-download-${report.reportId}`}>
                        <Download className="h-4 w-4" /> Download
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2 text-red-600 hover:text-red-700" onClick={() => handleDelete(report.reportId)} data-testid={`button-delete-${report.reportId}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{selectedReport?.title}</DialogTitle>
            <DialogDescription>
              Generated on {selectedReport ? new Date(selectedReport.dateCreated).toLocaleString() : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-auto">
            {selectedReport?.data && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Project Title</p>
                    <p className="font-medium">{selectedReport.data.projectTitle || "N/A"}</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Complexity</p>
                    <p className="font-medium">{selectedReport.data.complexityLevel || "N/A"}</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Timeline</p>
                    <p className="font-medium">{selectedReport.data.timeline || "N/A"}</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Estimated Cost</p>
                    <p className="font-medium">{selectedReport.data.estimatedCost || "N/A"}</p>
                  </div>
                </div>

                {selectedReport.data.teamAllocated?.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Team Allocated</h4>
                    <div className="space-y-2">
                      {selectedReport.data.teamAllocated.map((t: any, i: number) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-muted/50 rounded">
                          <span className="font-medium">{t.member || "Unassigned"}</span>
                          <Badge variant="outline">{t.role}</Badge>
                          <Badge className={t.status === "available" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>{t.status}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedReport.data.resourcesAllocated?.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Resources Allocated</h4>
                    <div className="space-y-2">
                      {selectedReport.data.resourcesAllocated.map((r: any, i: number) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-muted/50 rounded">
                          <span className="font-medium">{r.resource}</span>
                          <Badge variant="outline">Qty: {r.quantity}</Badge>
                          {r.lab && <span className="text-xs text-muted-foreground">{r.lab}</span>}
                          <Badge className={r.status === "available" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>{r.status}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedReport.data.deallocationSummary && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium mb-2">Deallocation Summary</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <p>Team Members Deallocated: <span className="font-medium">{selectedReport.data.deallocationSummary.teamDeallocated}</span></p>
                      <p>Resources Deallocated: <span className="font-medium">{selectedReport.data.deallocationSummary.resourcesDeallocated}</span></p>
                    </div>
                  </div>
                )}

                {selectedReport.data.hadResourceShortage && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-yellow-800 text-sm">This project had resource shortages during its lifecycle.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

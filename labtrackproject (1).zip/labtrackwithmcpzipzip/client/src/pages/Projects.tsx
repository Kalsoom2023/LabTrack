import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Edit2, Trash2, X, ChevronDown, ChevronUp } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";

interface Project {
  projectId: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  status: string;
  labId: number;
}

interface Lab {
  labId: number;
  labName: string;
  location: string;
}

interface Resource {
  resourceId: number;
  name: string;
  quantity: number;
}

interface ProjectResource {
  projectResourceId: number;
  projectId: number;
  resourceId: number;
  allocatedQuantity: number;
}

export default function Projects() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [labs, setLabs] = useState<Lab[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [projectResources, setProjectResources] = useState<ProjectResource[]>([]);
  const [expandedProject, setExpandedProject] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startDate: "",
    endDate: "",
    status: "Ongoing",
    labId: 1,
  });

  useEffect(() => {
    fetchProjects();
    fetchLabs();
    fetchResources();
  }, []);

  const fetchProjects = async () => {
    try {
      const res = await fetch("/api/projects");
      const data = await res.json();
      setProjects(Array.isArray(data) ? data : []);
      // Fetch project resources for all projects
      if (Array.isArray(data)) {
        for (const project of data) {
          await fetchProjectResources(project.projectId);
        }
      }
    } catch (error) {
      console.error("Failed to fetch projects:", error);
      setProjects([]);
    }
  };

  const fetchProjectResources = async (projectId: number) => {
    try {
      const res = await fetch(`/api/projects/${projectId}/resources`);
      const data = await res.json();
      setProjectResources((prev) => [
        ...prev.filter((pr) => pr.projectId !== projectId),
        ...(Array.isArray(data) ? data : []),
      ]);
    } catch (error) {
      console.error("Failed to fetch project resources:", error);
    }
  };

  const fetchLabs = async () => {
    try {
      const res = await fetch("/api/labs");
      const data = await res.json();
      setLabs(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch labs:", error);
      setLabs([]);
    }
  };

  const fetchResources = async () => {
    try {
      const res = await fetch("/api/resources");
      const data = await res.json();
      setResources(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch resources:", error);
      setResources([]);
    }
  };

  const getLabName = (labId: number) => {
    const lab = labs.find((l) => l.labId === labId);
    return lab ? lab.labName : "Unknown Lab";
  };

  const getResourceName = (resourceId: number) => {
    const resource = resources.find((r) => r.resourceId === resourceId);
    return resource ? resource.name : "Unknown Resource";
  };

  const getProjectResources = (projectId: number) => {
    return projectResources.filter((pr) => pr.projectId === projectId);
  };

  const handleSubmit = async () => {
    try {
      const method = editingProject ? "PUT" : "POST";
      const url = editingProject ? `/api/projects/${editingProject.projectId}` : "/api/projects";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        fetchProjects();
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save project:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this project?")) return;

    try {
      const res = await fetch(`/api/projects/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchProjects();
      }
    } catch (error) {
      console.error("Failed to delete project:", error);
    }
  };

  const handleEdit = (project: Project) => {
    setEditingProject(project);
    setFormData({
      title: project.title,
      description: project.description,
      startDate: project.startDate,
      endDate: project.endDate,
      status: project.status,
      labId: project.labId,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingProject(null);
    setFormData({
      title: "",
      description: "",
      startDate: "",
      endDate: "",
      status: "Ongoing",
      labId: 1,
    });
  };

  const isAdmin = user?.role === "Administrator";

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ongoing":
        return "bg-blue-500 text-white";
      case "Completed":
        return "bg-green-500 text-white";
      case "Paused":
        return "bg-yellow-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Projects
            </h1>
            <p className="text-muted-foreground mt-2">View and manage lab research and development projects.</p>
          </div>
          {isAdmin && (
            <Button
              onClick={() => setShowForm(!showForm)}
              className="gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              data-testid="button-new-project"
            >
              <Plus className="h-4 w-4" /> New Project
            </Button>
          )}
        </div>

        {isAdmin && showForm && (
          <Card className="border-indigo-200 dark:border-indigo-800 shadow-lg">
            <CardHeader className="border-b border-indigo-200 dark:border-indigo-800">
              <CardTitle className="text-indigo-600">
                {editingProject ? "Edit Project" : "Create New Project"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <Input
                placeholder="Project Title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-title"
              />
              <Input
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-description"
              />
              <div className="grid grid-cols-2 gap-4">
                <Input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                  data-testid="input-startDate"
                />
                <Input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                  data-testid="input-endDate"
                />
              </div>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="w-full px-3 py-2 border border-indigo-200 rounded-md focus:border-indigo-500 focus:ring-indigo-500"
                data-testid="select-status"
              >
                <option value="Ongoing">Ongoing</option>
                <option value="Completed">Completed</option>
                <option value="Paused">Paused</option>
              </select>
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={handleSubmit}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white hover:shadow-lg transition-all duration-200"
                  data-testid="button-save-project"
                >
                  {editingProject ? "Update Project" : "Create Project"}
                </Button>
                <Button
                  onClick={resetForm}
                  variant="outline"
                  className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4">
          {projects.map((project) => (
            <Card
              key={project.projectId}
              className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 group"
              data-testid={`card-project-${project.projectId}`}
            >
              <div className="h-1 bg-gradient-to-r from-indigo-500 to-purple-500" />
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <CardTitle className="group-hover:text-indigo-600 transition-colors" data-testid={`text-title-${project.projectId}`}>
                      {project.title}
                    </CardTitle>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(project.status)} data-testid={`badge-status-${project.projectId}`}>
                      {project.status}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        setExpandedProject(
                          expandedProject === project.projectId ? null : project.projectId
                        )
                      }
                      className="hover:bg-indigo-100 dark:hover:bg-indigo-900"
                      data-testid={`button-details-${project.projectId}`}
                    >
                      {expandedProject === project.projectId ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {expandedProject === project.projectId && (
                <CardContent className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-4">
                  <div>
                    <p className="text-sm text-muted-foreground" data-testid={`text-description-${project.projectId}`}>
                      {project.description}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground text-xs">Start Date</span>
                      <p className="font-semibold" data-testid={`text-startDate-${project.projectId}`}>
                        {new Date(project.startDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <span className="text-muted-foreground text-xs">End Date</span>
                      <p className="font-semibold" data-testid={`text-endDate-${project.projectId}`}>
                        {new Date(project.endDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                    <h4 className="font-semibold text-sm mb-3">Lab & Resources</h4>
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg bg-indigo-50 dark:bg-indigo-900/30">
                        <p className="text-xs text-muted-foreground">Lab</p>
                        <p className="font-medium" data-testid={`text-lab-${project.projectId}`}>
                          {getLabName(project.labId)}
                        </p>
                      </div>

                      {getProjectResources(project.projectId).length > 0 && (
                        <div className="space-y-2">
                          <p className="text-xs text-muted-foreground">Resources Allocated</p>
                          {getProjectResources(project.projectId).map((pr) => (
                            <div
                              key={pr.projectResourceId}
                              className="p-2 rounded bg-gray-100 dark:bg-gray-800 text-sm"
                              data-testid={`resource-${pr.projectResourceId}`}
                            >
                              <div className="font-medium">{getResourceName(pr.resourceId)}</div>
                              <div className="text-xs text-muted-foreground">
                                Allocated: {pr.allocatedQuantity} unit(s)
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {isAdmin && (
                    <div className="flex gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <Button
                        onClick={() => handleEdit(project)}
                        variant="outline"
                        size="sm"
                        className="flex-1 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
                        data-testid={`button-edit-${project.projectId}`}
                      >
                        <Edit2 className="h-4 w-4 mr-2" /> Edit
                      </Button>
                      <Button
                        onClick={() => handleDelete(project.projectId)}
                        variant="outline"
                        size="sm"
                        className="flex-1 hover:bg-red-100 dark:hover:bg-red-900 transition-colors"
                        data-testid={`button-delete-${project.projectId}`}
                      >
                        <Trash2 className="h-4 w-4 mr-2" /> Delete
                      </Button>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}

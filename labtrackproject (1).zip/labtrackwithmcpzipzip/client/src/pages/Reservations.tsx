import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, CheckCircle2, XCircle, Calendar as CalendarIcon, Edit2, Trash2, X, ChevronDown, ChevronUp } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";

interface Reservation {
  reservationId: number;
  resourceId: number;
  labId: number;
  userId: number;
  startTime: string;
  endTime: string;
  purpose: string;
  status: string;
  approvedBy: number | null;
}

interface Lab {
  labId: number;
  labName: string;
  location: string;
}

interface Resource {
  resourceId: number;
  name: string;
  quantity: number;
}

export default function Reservations() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [labs, setLabs] = useState<Lab[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingReservation, setEditingReservation] = useState<Reservation | null>(null);
  const [expandedReservation, setExpandedReservation] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    resourceId: 0,
    labId: 0,
    startTime: "",
    endTime: "",
    purpose: "",
  });

  useEffect(() => {
    fetchReservations();
    fetchLabs();
    fetchResources();
  }, []);

  const fetchReservations = async () => {
    try {
      const res = await fetch("/api/reservations");
      const data = await res.json();
      setReservations(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch reservations:", error);
      setReservations([]);
    }
  };

  const fetchLabs = async () => {
    try {
      const res = await fetch("/api/labs");
      const data = await res.json();
      setLabs(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch labs:", error);
      setLabs([]);
    }
  };

  const fetchResources = async () => {
    try {
      const res = await fetch("/api/resources");
      const data = await res.json();
      setResources(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch resources:", error);
      setResources([]);
    }
  };

  const getLabName = (labId: number) => {
    const lab = labs.find((l) => l.labId === labId);
    return lab ? lab.labName : "Unknown Lab";
  };

  const getResourceName = (resourceId: number) => {
    const resource = resources.find((r) => r.resourceId === resourceId);
    return resource ? resource.name : "Unknown Resource";
  };

  const handleSubmit = async () => {
    if (!formData.resourceId || !formData.labId || !formData.startTime || !formData.endTime || !formData.purpose) {
      alert("Please fill in all fields");
      return;
    }

    try {
      const method = editingReservation ? "PUT" : "POST";
      const url = editingReservation ? `/api/reservations/${editingReservation.reservationId}` : "/api/reservations";

      const payload = {
        ...formData,
        resourceId: parseInt(formData.resourceId.toString()),
        labId: parseInt(formData.labId.toString()),
        userId: user?.userId || 1,
      };

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        fetchReservations();
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save reservation:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this reservation?")) return;

    try {
      const res = await fetch(`/api/reservations/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchReservations();
      }
    } catch (error) {
      console.error("Failed to delete reservation:", error);
    }
  };

  const handleEdit = (reservation: Reservation) => {
    setEditingReservation(reservation);
    setFormData({
      resourceId: reservation.resourceId,
      labId: reservation.labId,
      startTime: reservation.startTime.slice(0, 16),
      endTime: reservation.endTime.slice(0, 16),
      purpose: reservation.purpose,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingReservation(null);
    setFormData({
      resourceId: 0,
      labId: 0,
      startTime: "",
      endTime: "",
      purpose: "",
    });
  };

  const handleApprove = async (id: number) => {
    try {
      const res = await fetch(`/api/reservations/${id}/approve`, { method: "POST" });
      if (res.ok) {
        fetchReservations();
      }
    } catch (error) {
      console.error("Failed to approve reservation:", error);
    }
  };

  const handleReject = async (id: number) => {
    try {
      const res = await fetch(`/api/reservations/${id}/reject`, { method: "POST" });
      if (res.ok) {
        fetchReservations();
      }
    } catch (error) {
      console.error("Failed to reject reservation:", error);
    }
  };

  const isManager = user?.role === "Administrator" || user?.role === "Manager";

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Reservations</h1>
            <p className="text-muted-foreground mt-2">Track and manage lab and resource bookings efficiently.</p>
          </div>
          <Button 
            className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg hover:shadow-xl transition-all duration-200" 
            onClick={() => setShowForm(!showForm)}
            data-testid="button-new-reservation"
          >
            <Plus className="h-4 w-4" /> New Reservation
          </Button>
        </div>

        {showForm && (
          <Card className="shadow-lg border-2 border-amber-500 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950">
            <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-t-lg">
              <CardTitle>{editingReservation ? "Edit Reservation" : "Create New Reservation"}</CardTitle>
              <Button variant="ghost" size="sm" onClick={resetForm} className="hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <select
                value={formData.resourceId}
                onChange={(e) => setFormData({ ...formData, resourceId: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-amber-200 rounded-md focus:border-amber-500 focus:ring-amber-500"
                data-testid="select-resource"
              >
                <option value={0}>Select Resource</option>
                {resources.map((r) => (
                  <option key={r.resourceId} value={r.resourceId}>
                    {r.name}
                  </option>
                ))}
              </select>
              <select
                value={formData.labId}
                onChange={(e) => setFormData({ ...formData, labId: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-amber-200 rounded-md focus:border-amber-500 focus:ring-amber-500"
                data-testid="select-lab"
              >
                <option value={0}>Select Lab</option>
                {labs.map((l) => (
                  <option key={l.labId} value={l.labId}>
                    {l.labName}
                  </option>
                ))}
              </select>
              <Input
                type="datetime-local"
                placeholder="Start Time"
                value={formData.startTime}
                onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                className="border-amber-200 focus:border-amber-500 focus:ring-amber-500 hover:border-amber-300 transition-colors"
                data-testid="input-startTime"
              />
              <Input
                type="datetime-local"
                placeholder="End Time"
                value={formData.endTime}
                onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                className="border-amber-200 focus:border-amber-500 focus:ring-amber-500 hover:border-amber-300 transition-colors"
                data-testid="input-endTime"
              />
              <Input
                placeholder="Purpose"
                value={formData.purpose}
                onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                className="border-amber-200 focus:border-amber-500 focus:ring-amber-500 hover:border-amber-300 transition-colors"
                data-testid="input-purpose"
              />
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={handleSubmit}
                  className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white hover:shadow-lg transition-all duration-200"
                  data-testid="button-save-reservation"
                >
                  {editingReservation ? "Update Reservation" : "Create Reservation"}
                </Button>
                <Button
                  onClick={resetForm}
                  variant="outline"
                  className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3 bg-gradient-to-r from-gray-100 to-amber-100 dark:from-gray-900 dark:to-amber-900 p-1 rounded-lg">
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-orange-500 data-[state=active]:text-white transition-all duration-200">Upcoming</TabsTrigger>
            <TabsTrigger value="pending" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-orange-500 data-[state=active]:text-white transition-all duration-200">Pending</TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-orange-500 data-[state=active]:text-white transition-all duration-200">History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming" className="mt-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-200 border border-gray-200 dark:border-gray-700">
              <CardHeader className="border-b border-gray-200 dark:border-gray-700">
                <CardTitle className="text-amber-600 dark:text-amber-400">Upcoming Reservations</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ReservationCards
                  reservations={reservations} 
                  filterStatus={['Approved']}
                  isManager={isManager}
                  userId={user?.userId}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  getLabName={getLabName}
                  getResourceName={getResourceName}
                  expandedReservation={expandedReservation}
                  setExpandedReservation={setExpandedReservation}
                />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="pending" className="mt-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-200 border border-gray-200 dark:border-gray-700">
              <CardHeader className="border-b border-gray-200 dark:border-gray-700">
                <CardTitle className="text-amber-600 dark:text-amber-400">Pending Approval</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ReservationCards
                  reservations={reservations} 
                  filterStatus={['Pending']}
                  isManager={isManager}
                  userId={user?.userId}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  getLabName={getLabName}
                  getResourceName={getResourceName}
                  expandedReservation={expandedReservation}
                  setExpandedReservation={setExpandedReservation}
                />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="history" className="mt-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-200 border border-gray-200 dark:border-gray-700">
              <CardHeader className="border-b border-gray-200 dark:border-gray-700">
                <CardTitle className="text-amber-600 dark:text-amber-400">Past Reservations</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <ReservationCards
                  reservations={reservations} 
                  filterStatus={['Completed', 'Rejected']}
                  isManager={isManager}
                  userId={user?.userId}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  getLabName={getLabName}
                  getResourceName={getResourceName}
                  expandedReservation={expandedReservation}
                  setExpandedReservation={setExpandedReservation}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function ReservationCards({ 
  reservations, 
  filterStatus, 
  isManager,
  userId,
  onApprove,
  onReject,
  onEdit,
  onDelete,
  getLabName,
  getResourceName,
  expandedReservation,
  setExpandedReservation
}: { 
  reservations: Reservation[]
  filterStatus: string[]
  isManager: boolean
  userId?: number
  onApprove: (id: number) => void
  onReject: (id: number) => void
  onEdit: (reservation: Reservation) => void
  onDelete: (id: number) => void
  getLabName: (labId: number) => string
  getResourceName: (resourceId: number) => string
  expandedReservation: number | null
  setExpandedReservation: (id: number | null) => void
}) {
  const filtered = reservations.filter(r => filterStatus.includes(r.status));

  if (filtered.length === 0) {
    return <div className="text-center py-12 text-muted-foreground text-lg">No reservations found.</div>;
  }

  return (
    <div className="grid gap-4">
      {filtered.map((reservation) => (
        <Card
          key={reservation.reservationId}
          className="overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 border-0 group"
          data-testid={`card-reservation-${reservation.reservationId}`}
        >
          <div className="h-1 bg-gradient-to-r from-amber-500 to-orange-500" />
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <CardTitle className="group-hover:text-amber-600 transition-colors" data-testid={`text-resource-${reservation.reservationId}`}>
                  {getResourceName(reservation.resourceId)}
                </CardTitle>
                <div className="flex gap-2 items-center mt-2 text-sm text-muted-foreground">
                  <span>{getLabName(reservation.labId)}</span>
                  <Badge 
                    className={`font-semibold ${
                      reservation.status === 'Approved' ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white' : 
                      reservation.status === 'Pending' ? 'bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 text-white' : 
                      'bg-gradient-to-r from-red-500 to-rose-500 hover:from-red-600 hover:to-rose-600 text-white'
                    }`}
                    data-testid={`badge-status-${reservation.reservationId}`}
                  >
                    {reservation.status}
                  </Badge>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() =>
                  setExpandedReservation(
                    expandedReservation === reservation.reservationId ? null : reservation.reservationId
                  )
                }
                className="hover:bg-amber-100 dark:hover:bg-amber-900"
                data-testid={`button-details-${reservation.reservationId}`}
              >
                {expandedReservation === reservation.reservationId ? (
                  <ChevronUp className="h-4 w-4" />
                ) : (
                  <ChevronDown className="h-4 w-4" />
                )}
              </Button>
            </div>
          </CardHeader>

          {expandedReservation === reservation.reservationId && (
            <CardContent className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/30">
                  <p className="text-xs text-muted-foreground">Start</p>
                  <p className="font-semibold">{new Date(reservation.startTime).toLocaleDateString()}</p>
                  <p className="text-xs">{new Date(reservation.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
                <div className="p-3 rounded-lg bg-orange-50 dark:bg-orange-900/30">
                  <p className="text-xs text-muted-foreground">End</p>
                  <p className="font-semibold">{new Date(reservation.endTime).toLocaleDateString()}</p>
                  <p className="text-xs">{new Date(reservation.endTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                <p className="text-xs text-muted-foreground">Purpose</p>
                <p className="font-semibold text-gray-900 dark:text-gray-100">{reservation.purpose}</p>
              </div>

              <div className="flex gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                {isManager && reservation.status === 'Pending' && (
                  <>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onApprove(reservation.reservationId)}
                      className="flex-1 gap-1 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-100 dark:hover:bg-emerald-900 hover:border-emerald-400 transition-all duration-200"
                      data-testid={`button-approve-${reservation.reservationId}`}
                    >
                      <CheckCircle2 className="h-4 w-4" /> Approve
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onReject(reservation.reservationId)}
                      className="flex-1 gap-1 text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900 hover:border-red-400 transition-all duration-200"
                      data-testid={`button-reject-${reservation.reservationId}`}
                    >
                      <XCircle className="h-4 w-4" /> Reject
                    </Button>
                  </>
                )}
                {(userId === reservation.userId || isManager) && reservation.status !== 'Completed' && reservation.status !== 'Rejected' && (
                  <>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onEdit(reservation)}
                      className="flex-1 gap-1 hover:bg-amber-100 dark:hover:bg-amber-900 hover:text-amber-700 dark:hover:text-amber-300 hover:border-amber-400 transition-all duration-200"
                      data-testid={`button-edit-${reservation.reservationId}`}
                    >
                      <Edit2 className="h-4 w-4" /> Edit
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onDelete(reservation.reservationId)}
                      className="flex-1 gap-1 text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900 hover:border-red-400 transition-all duration-200"
                      data-testid={`button-delete-${reservation.reservationId}`}
                    >
                      <Trash2 className="h-4 w-4" /> Delete
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
}

import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { RESOURCES, LABS, ALERTS, RESERVATIONS } from "@/lib/mockData";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AlertCircle, CheckCircle2, Clock, Users, Brain, Zap, DollarSign, Calendar, ChevronDown, ChevronUp, RefreshCw, Target, Plus, Send } from "lucide-react";
import { useState, useEffect } from "react";

interface MCPProject {
  id: string;
  originalInput: {
    title?: string;
    description?: string;
    estimated_cost: number;
    estimated_time_needed: string;
    required_team: string[];
    required_resources: string[];
    complexity_level: string;
    submittedAt?: string;
  };
  aiRecommendations: {
    team_allocation: {
      role: string;
      assigned_member?: string;
      lab_assignment?: string;
      availability_status: string;
      allocation_reasoning: string;
    }[];
    resource_allocation: {
      resource: string;
      assigned_lab?: string;
      quantity_needed: number;
      availability_status: string;
      alternative_suggestion?: string;
      allocation_reasoning: string;
    }[];
    timeline_adjustments: {
      original_timeline: string;
      recommended_timeline: string;
      adjustment_reason: string;
      milestones: { phase: string; duration: string; description: string }[];
    };
    budget_optimization: {
      original_cost: number;
      optimized_cost: number;
      savings_percentage: number;
      optimization_tips: string[];
    };
    risk_assessment: {
      risk_level: string;
      identified_risks: string[];
      mitigation_strategies: string[];
    };
    overall_recommendations: string[];
    confidence_score: number;
  };
  processedAt: string;
  status: "pending" | "processing" | "completed" | "failed";
  error?: string;
}

interface NewProjectForm {
  title: string;
  description: string;
  estimated_cost: string;
  estimated_time_needed: string;
  required_team: string;
  required_resources: string;
  complexity_level: string;
}

const initialFormState: NewProjectForm = {
  title: "",
  description: "",
  estimated_cost: "",
  estimated_time_needed: "",
  required_team: "",
  required_resources: "",
  complexity_level: "Medium"
};

export default function Dashboard() {
  const [mcpProjects, setMcpProjects] = useState<MCPProject[]>([]);
  const [expandedProject, setExpandedProject] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState<NewProjectForm>(initialFormState);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const totalResources = RESOURCES.length;
  const availableResources = RESOURCES.filter(r => r.status === "Available").length;
  const activeAlerts = ALERTS.filter(a => !a.is_resolved).length;
  const activeLabs = LABS.filter(l => l.status === "Open").length;

  useEffect(() => {
    fetchMCPProjects();
    const interval = setInterval(fetchMCPProjects, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchMCPProjects = async () => {
    try {
      const res = await fetch("/api/mcp/projects");
      if (res.ok) {
        const data = await res.json();
        setMcpProjects(data);
      }
    } catch (error) {
      console.error("Failed to fetch MCP projects:", error);
    }
  };

  const reprocessProject = async (projectId: string) => {
    setLoading(true);
    try {
      await fetch(`/api/mcp/projects/${projectId}/reprocess`, { method: "POST" });
      await fetchMCPProjects();
    } catch (error) {
      console.error("Failed to reprocess project:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitProject = async () => {
    setSubmitError(null);
    
    if (!formData.title.trim()) {
      setSubmitError("Project title is required");
      return;
    }
    if (!formData.estimated_cost || isNaN(Number(formData.estimated_cost))) {
      setSubmitError("Please enter a valid estimated cost");
      return;
    }
    if (!formData.estimated_time_needed.trim()) {
      setSubmitError("Estimated timeline is required");
      return;
    }
    if (!formData.required_team.trim()) {
      setSubmitError("At least one team role is required");
      return;
    }
    if (!formData.required_resources.trim()) {
      setSubmitError("At least one resource is required");
      return;
    }

    setSubmitting(true);
    try {
      const projectData = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        estimated_cost: Number(formData.estimated_cost),
        estimated_time_needed: formData.estimated_time_needed.trim(),
        required_team: formData.required_team.split(",").map(s => s.trim()).filter(s => s),
        required_resources: formData.required_resources.split(",").map(s => s.trim()).filter(s => s),
        complexity_level: formData.complexity_level
      };

      const res = await fetch("/api/mcp/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(projectData)
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to submit project");
      }

      setFormData(initialFormState);
      setDialogOpen(false);
      await fetchMCPProjects();
    } catch (error: any) {
      console.error("Failed to submit project:", error);
      setSubmitError(error.message || "Failed to submit project");
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500 text-white";
      case "processing": return "bg-blue-500 text-white";
      case "pending": return "bg-yellow-500 text-white";
      case "failed": return "bg-red-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getAvailabilityColor = (status: string) => {
    switch (status) {
      case "available": return "text-green-600 bg-green-100";
      case "partial": return "text-yellow-600 bg-yellow-100";
      case "unavailable": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case "low": return "text-green-600 bg-green-100";
      case "medium": return "text-yellow-600 bg-yellow-100";
      case "high": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of lab resources and AI-powered project management.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-l-4 border-l-primary shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Resources</CardTitle>
              <BoxIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalResources}</div>
              <p className="text-xs text-muted-foreground">Across {LABS.length} labs</p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-emerald-500 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Labs Active</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeLabs}/{LABS.length}</div>
              <p className="text-xs text-muted-foreground">Currently open</p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-purple-500 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Projects</CardTitle>
              <Brain className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mcpProjects.filter(p => p.status === "completed").length}</div>
              <p className="text-xs text-muted-foreground">Processed by Agentic AI</p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-destructive shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
              <AlertCircle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeAlerts}</div>
              <p className="text-xs text-muted-foreground">Requires attention</p>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-lg border-purple-200">
          <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-blue-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500 rounded-lg">
                  <Brain className="h-5 w-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg">Agentic AI - MCP Projects</CardTitle>
                  <p className="text-sm text-muted-foreground">AI-powered resource allocation and team recommendations</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={fetchMCPProjects} className="gap-2">
                  <RefreshCw className="h-4 w-4" /> Refresh
                </Button>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-2 bg-purple-600 hover:bg-purple-700">
                      <Plus className="h-4 w-4" /> Submit New Project
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Brain className="h-5 w-5 text-purple-600" />
                        Submit Project for AI Analysis
                      </DialogTitle>
                      <DialogDescription>
                        Enter your project details below. The AI will analyze and provide recommendations for team allocation, resource allocation, timeline, budget optimization, and risk assessment.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="title">Project Title *</Label>
                        <Input
                          id="title"
                          placeholder="e.g., AI-Powered Lab Management System"
                          value={formData.title}
                          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          placeholder="Brief description of the project..."
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="cost">Estimated Cost ($) *</Label>
                          <Input
                            id="cost"
                            type="number"
                            placeholder="e.g., 25000"
                            value={formData.estimated_cost}
                            onChange={(e) => setFormData({ ...formData, estimated_cost: e.target.value })}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="timeline">Estimated Timeline *</Label>
                          <Input
                            id="timeline"
                            placeholder="e.g., 3 months"
                            value={formData.estimated_time_needed}
                            onChange={(e) => setFormData({ ...formData, estimated_time_needed: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="team">Required Team Roles * (comma-separated)</Label>
                        <Input
                          id="team"
                          placeholder="e.g., Project Manager, Frontend Developer, Backend Developer, UI/UX Designer"
                          value={formData.required_team}
                          onChange={(e) => setFormData({ ...formData, required_team: e.target.value })}
                        />
                        <p className="text-xs text-muted-foreground">Enter team roles separated by commas</p>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="resources">Required Resources * (comma-separated)</Label>
                        <Input
                          id="resources"
                          placeholder="e.g., Laptops, Server, GPU, Monitors"
                          value={formData.required_resources}
                          onChange={(e) => setFormData({ ...formData, required_resources: e.target.value })}
                        />
                        <p className="text-xs text-muted-foreground">Enter required resources separated by commas</p>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="complexity">Complexity Level *</Label>
                        <Select
                          value={formData.complexity_level}
                          onValueChange={(value) => setFormData({ ...formData, complexity_level: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select complexity" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Low">Low</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {submitError && (
                        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">
                          {submitError}
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleSubmitProject} 
                        disabled={submitting}
                        className="gap-2 bg-purple-600 hover:bg-purple-700"
                      >
                        {submitting ? (
                          <>
                            <RefreshCw className="h-4 w-4 animate-spin" /> Submitting...
                          </>
                        ) : (
                          <>
                            <Send className="h-4 w-4" /> Submit for AI Analysis
                          </>
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {mcpProjects.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Brain className="h-12 w-12 mx-auto mb-4 opacity-30" />
                <p className="font-medium">No MCP projects yet</p>
                <p className="text-sm mt-1">Projects submitted through MCP will appear here with AI recommendations</p>
              </div>
            ) : (
              <div className="divide-y">
                {mcpProjects.map((project) => (
                  <div key={project.id} className="p-4">
                    <div className="flex items-center justify-between cursor-pointer" 
                         onClick={() => setExpandedProject(expandedProject === project.id ? null : project.id)}>
                      <div className="flex items-center gap-4">
                        <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg">
                          <Zap className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold">{project.originalInput.title || `Project ${project.id.slice(0, 8)}`}</h4>
                          <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <DollarSign className="h-3 w-3" /> ${project.originalInput.estimated_cost.toLocaleString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" /> {project.originalInput.estimated_time_needed}
                            </span>
                            <Badge variant="outline">{project.originalInput.complexity_level}</Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                        {project.status === "completed" && project.aiRecommendations && (
                          <Badge variant="outline" className="gap-1">
                            <Target className="h-3 w-3" />
                            {project.aiRecommendations.confidence_score}% confidence
                          </Badge>
                        )}
                        {expandedProject === project.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </div>
                    </div>

                    {expandedProject === project.id && (
                      <div className="mt-4 pt-4 border-t space-y-6">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                            <h5 className="font-semibold text-blue-700 mb-3 flex items-center gap-2">
                              <Users className="h-4 w-4" /> Original Input - Required Team
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {project.originalInput.required_team.map((role, idx) => (
                                <Badge key={idx} variant="outline" className="bg-white">{role}</Badge>
                              ))}
                            </div>
                          </div>
                          <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                            <h5 className="font-semibold text-green-700 mb-3 flex items-center gap-2">
                              <BoxIcon className="h-4 w-4" /> Original Input - Required Resources
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {project.originalInput.required_resources.map((res, idx) => (
                                <Badge key={idx} variant="outline" className="bg-white">{res}</Badge>
                              ))}
                            </div>
                          </div>
                        </div>

                        {project.status === "completed" && project.aiRecommendations && (
                          <>
                            <div className="p-4 rounded-lg bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200">
                              <h5 className="font-semibold text-purple-700 mb-4 flex items-center gap-2">
                                <Brain className="h-4 w-4" /> AI Team Allocation Recommendations
                              </h5>
                              <div className="space-y-3">
                                {project.aiRecommendations.team_allocation.map((alloc, idx) => (
                                  <div key={idx} className="p-3 bg-white rounded-lg border">
                                    <div className="flex items-center justify-between mb-2">
                                      <span className="font-medium">{alloc.role}</span>
                                      <Badge className={getAvailabilityColor(alloc.availability_status)}>
                                        {alloc.availability_status}
                                      </Badge>
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                      {alloc.assigned_member ? (
                                        <>Assigned: <span className="font-medium text-foreground">{alloc.assigned_member}</span></>
                                      ) : "No team member assigned"}
                                      {alloc.lab_assignment && <> | Lab: <span className="font-medium text-foreground">{alloc.lab_assignment}</span></>}
                                    </p>
                                    <p className="text-xs text-muted-foreground mt-1">{alloc.allocation_reasoning}</p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="p-4 rounded-lg bg-gradient-to-r from-green-50 to-teal-50 border border-green-200">
                              <h5 className="font-semibold text-green-700 mb-4 flex items-center gap-2">
                                <BoxIcon className="h-4 w-4" /> AI Resource Allocation Recommendations
                              </h5>
                              <div className="space-y-3">
                                {project.aiRecommendations.resource_allocation.map((alloc, idx) => (
                                  <div key={idx} className="p-3 bg-white rounded-lg border">
                                    <div className="flex items-center justify-between mb-2">
                                      <span className="font-medium">{alloc.resource}</span>
                                      <Badge className={getAvailabilityColor(alloc.availability_status)}>
                                        {alloc.availability_status}
                                      </Badge>
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                      Quantity: {alloc.quantity_needed} | Lab: {alloc.assigned_lab || "TBD"}
                                    </p>
                                    <p className="text-xs text-muted-foreground mt-1">{alloc.allocation_reasoning}</p>
                                    {alloc.alternative_suggestion && (
                                      <p className="text-xs text-blue-600 mt-1">Alternative: {alloc.alternative_suggestion}</p>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                                <h5 className="font-semibold text-amber-700 mb-3 flex items-center gap-2">
                                  <Calendar className="h-4 w-4" /> Timeline Adjustments
                                </h5>
                                <div className="space-y-2 text-sm">
                                  <p><span className="text-muted-foreground">Original:</span> {project.aiRecommendations.timeline_adjustments.original_timeline}</p>
                                  <p><span className="text-muted-foreground">Recommended:</span> <span className="font-medium">{project.aiRecommendations.timeline_adjustments.recommended_timeline}</span></p>
                                  <p className="text-xs text-muted-foreground">{project.aiRecommendations.timeline_adjustments.adjustment_reason}</p>
                                  <div className="mt-3 space-y-2">
                                    {project.aiRecommendations.timeline_adjustments.milestones.map((m, idx) => (
                                      <div key={idx} className="flex items-center gap-2 text-xs">
                                        <div className="w-2 h-2 rounded-full bg-amber-500" />
                                        <span className="font-medium">{m.phase}</span> - {m.duration}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>

                              <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                                <h5 className="font-semibold text-emerald-700 mb-3 flex items-center gap-2">
                                  <DollarSign className="h-4 w-4" /> Budget Optimization
                                </h5>
                                <div className="space-y-2 text-sm">
                                  <p><span className="text-muted-foreground">Original Cost:</span> ${project.aiRecommendations.budget_optimization.original_cost.toLocaleString()}</p>
                                  <p><span className="text-muted-foreground">Optimized Cost:</span> <span className="font-medium text-emerald-600">${project.aiRecommendations.budget_optimization.optimized_cost.toLocaleString()}</span></p>
                                  <p className="text-emerald-600 font-medium">Potential Savings: {project.aiRecommendations.budget_optimization.savings_percentage}%</p>
                                  <div className="mt-2 space-y-1">
                                    {project.aiRecommendations.budget_optimization.optimization_tips.map((tip, idx) => (
                                      <p key={idx} className="text-xs text-muted-foreground flex items-start gap-1">
                                        <CheckCircle2 className="h-3 w-3 mt-0.5 text-emerald-500" /> {tip}
                                      </p>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                              <div className="flex items-center justify-between mb-3">
                                <h5 className="font-semibold text-red-700 flex items-center gap-2">
                                  <AlertCircle className="h-4 w-4" /> Risk Assessment
                                </h5>
                                <Badge className={getRiskColor(project.aiRecommendations.risk_assessment.risk_level)}>
                                  {project.aiRecommendations.risk_assessment.risk_level} risk
                                </Badge>
                              </div>
                              <div className="grid md:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <p className="font-medium mb-2">Identified Risks:</p>
                                  <ul className="space-y-1">
                                    {project.aiRecommendations.risk_assessment.identified_risks.map((risk, idx) => (
                                      <li key={idx} className="text-xs text-muted-foreground flex items-start gap-1">
                                        <AlertCircle className="h-3 w-3 mt-0.5 text-red-400" /> {risk}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                <div>
                                  <p className="font-medium mb-2">Mitigation Strategies:</p>
                                  <ul className="space-y-1">
                                    {project.aiRecommendations.risk_assessment.mitigation_strategies.map((strat, idx) => (
                                      <li key={idx} className="text-xs text-muted-foreground flex items-start gap-1">
                                        <CheckCircle2 className="h-3 w-3 mt-0.5 text-green-400" /> {strat}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>

                            <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                              <h5 className="font-semibold text-blue-700 mb-3 flex items-center gap-2">
                                <Brain className="h-4 w-4" /> Overall AI Recommendations
                              </h5>
                              <ul className="space-y-2">
                                {project.aiRecommendations.overall_recommendations.map((rec, idx) => (
                                  <li key={idx} className="text-sm flex items-start gap-2">
                                    <Zap className="h-4 w-4 mt-0.5 text-blue-500" /> {rec}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </>
                        )}

                        {project.status === "failed" && (
                          <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                            <p className="text-red-600">Processing failed: {project.error || "Unknown error"}</p>
                            <Button onClick={() => reprocessProject(project.id)} disabled={loading} className="mt-2" size="sm">
                              <RefreshCw className="h-4 w-4 mr-2" /> Retry Processing
                            </Button>
                          </div>
                        )}

                        {project.status === "processing" && (
                          <div className="p-4 rounded-lg bg-blue-50 border border-blue-200 text-center">
                            <RefreshCw className="h-6 w-6 mx-auto mb-2 animate-spin text-blue-500" />
                            <p className="text-blue-600">AI is analyzing this project...</p>
                          </div>
                        )}

                        {project.status === "pending" && (
                          <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-200 text-center">
                            <Clock className="h-6 w-6 mx-auto mb-2 text-yellow-500" />
                            <p className="text-yellow-600">Waiting for AI processing...</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4 shadow-sm">
            <CardHeader>
              <CardTitle>Resource Availability</CardTitle>
            </CardHeader>
            <CardContent className="pl-2">
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={RESOURCES.reduce((acc: any[], curr) => {
                    const existing = acc.find(item => item.category === curr.category);
                    if (existing) {
                      existing.total += 1;
                      if (curr.status === "Available") existing.available += 1;
                    } else {
                      acc.push({ 
                        category: curr.category, 
                        total: 1, 
                        available: curr.status === "Available" ? 1 : 0 
                      });
                    }
                    return acc;
                  }, [])}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="category" tickLine={false} axisLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <YAxis tickLine={false} axisLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                      cursor={{fill: 'hsl(var(--muted)/0.2)'}}
                    />
                    <Bar dataKey="total" fill="hsl(var(--primary)/0.3)" radius={[4, 4, 0, 0]} name="Total Items" />
                    <Bar dataKey="available" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Available Now" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-3 shadow-sm">
            <CardHeader>
              <CardTitle>Recent Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ALERTS.slice(0, 5).map((alert) => {
                   const resource = RESOURCES.find(r => r.resource_id === alert.resource_id);
                   return (
                    <div key={alert.alert_id} className="flex items-start gap-3 pb-3 border-b border-border last:border-0">
                      <div className={`mt-0.5 rounded-full p-1.5 ${alert.severity === 'High' ? 'bg-destructive/10 text-destructive' : 'bg-amber-500/10 text-amber-500'}`}>
                        <AlertCircle className="h-4 w-4" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">{alert.alert_type}</p>
                        <p className="text-xs text-muted-foreground">
                          {resource?.name} • {new Date(alert.created_on).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                   );
                })}
                {ALERTS.length === 0 && (
                  <div className="text-center text-sm text-muted-foreground py-4">No active alerts</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

function BoxIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  )
}

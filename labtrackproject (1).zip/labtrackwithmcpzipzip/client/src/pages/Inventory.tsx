import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, Filter, Plus, Edit2, Trash2, X, ChevronDown, ChevronUp } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";

interface Resource {
  resourceId: number;
  labId: number;
  categoryId: number;
  name: string;
  category: string;
  quantity: number;
  allocatedQuantity?: number;
  status: string;
  thresholdLevel: number;
  warrantyExpiry: string;
}

interface Lab {
  labId: number;
  labName: string;
  location: string;
}

export default function Inventory() {
  const { user } = useAuth();
  const [resources, setResources] = useState<Resource[]>([]);
  const [labs, setLabs] = useState<Lab[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingResource, setEditingResource] = useState<Resource | null>(null);
  const [expandedResource, setExpandedResource] = useState<number | null>(null);
  const [categories, setCategories] = useState<{categoryId: number; name: string}[]>([]);
  const [formData, setFormData] = useState({
    labId: 1,
    categoryId: 0,
    categoryName: "",
    name: "",
    category: "",
    quantity: 0,
    status: "Available",
    thresholdLevel: 5,
    warrantyExpiry: "",
  });

  useEffect(() => {
    fetchResources();
    fetchCategories();
    fetchLabs();
  }, []);

  const fetchResources = async () => {
    try {
      const res = await fetch("/api/resources");
      const data = await res.json();
      setResources(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch resources:", error);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch("/api/categories");
      const data = await res.json();
      setCategories(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch categories:", error);
    }
  };

  const fetchLabs = async () => {
    try {
      const res = await fetch("/api/labs");
      const data = await res.json();
      setLabs(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch labs:", error);
      setLabs([]);
    }
  };

  const getLabName = (labId: number) => {
    const lab = labs.find((l) => l.labId === labId);
    return lab ? lab.labName : "Unknown Lab";
  };

  const handleSubmit = async () => {
    try {
      const method = editingResource ? "PUT" : "POST";
      const url = editingResource ? `/api/resources/${editingResource.resourceId}` : "/api/resources";
      
      const dataToSend = {
        ...formData,
        category: formData.category || formData.categoryName,
      };
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dataToSend),
      });

      if (res.ok) {
        fetchResources();
        fetchCategories();
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save resource:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this resource?")) return;
    
    try {
      const res = await fetch(`/api/resources/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchResources();
      }
    } catch (error) {
      console.error("Failed to delete resource:", error);
    }
  };

  const handleEdit = (resource: Resource) => {
    setEditingResource(resource);
    setFormData({
      labId: resource.labId,
      categoryId: resource.categoryId,
      categoryName: "",
      name: resource.name,
      category: resource.category,
      quantity: resource.quantity,
      status: resource.status,
      thresholdLevel: resource.thresholdLevel,
      warrantyExpiry: resource.warrantyExpiry,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingResource(null);
    setFormData({
      labId: 1,
      categoryId: 0,
      categoryName: "",
      name: "",
      category: "",
      quantity: 0,
      status: "Available",
      thresholdLevel: 5,
      warrantyExpiry: "",
    });
  };

  const filteredResources = resources.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const isAdmin = user?.role === "Administrator" || user?.role === "Manager";

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">Inventory Management</h1>
            <p className="text-muted-foreground mt-2">Manage and track hardware and software resources across labs.</p>
          </div>
          {isAdmin && (
            <Button 
              className="gap-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-lg hover:shadow-xl transition-all duration-200" 
              onClick={() => { setShowForm(true); setEditingResource(null); }} 
              data-testid="button-create-resource"
            >
              <Plus className="h-4 w-4" /> Add Resource
            </Button>
          )}
        </div>

        {showForm && (
          <Card className="shadow-lg border-2 border-blue-500 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
            <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-t-lg">
              <CardTitle>{editingResource ? "Edit Resource" : "Create New Resource"}</CardTitle>
              <Button variant="ghost" size="sm" onClick={resetForm} className="hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <Input
                placeholder="Resource Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors"
                data-testid="input-resourceName"
              />
              <Input
                placeholder="Category Name"
                value={formData.categoryName}
                onChange={(e) => setFormData({ ...formData, categoryName: e.target.value })}
                className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors"
                data-testid="input-categoryName"
              />
              <Input
                type="number"
                placeholder="Quantity"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors"
                data-testid="input-quantity"
              />
              <Input
                type="number"
                placeholder="Threshold Level"
                value={formData.thresholdLevel}
                onChange={(e) => setFormData({ ...formData, thresholdLevel: parseInt(e.target.value) })}
                className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors"
                data-testid="input-thresholdLevel"
              />
              <Input
                type="date"
                placeholder="Warranty Expiry"
                value={formData.warrantyExpiry}
                onChange={(e) => setFormData({ ...formData, warrantyExpiry: e.target.value })}
                className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors"
                data-testid="input-warrantyExpiry"
              />
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors" data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="In Use">In Use</SelectItem>
                  <SelectItem value="Defective">Defective</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSubmit} className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white hover:shadow-lg transition-all duration-200" data-testid="button-save-resource">
                  {editingResource ? "Update Resource" : "Create Resource"}
                </Button>
                <Button onClick={resetForm} variant="outline" className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" data-testid="button-cancel">Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-200 border border-gray-200 dark:border-gray-700">
          <CardHeader className="pb-3 border-b border-gray-200 dark:border-gray-700">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="relative w-full md:w-72">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search resources..." 
                  className="pl-9 bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-900 dark:to-blue-900 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500 hover:border-blue-300 transition-colors" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  data-testid="input-search"
                />
              </div>
              <div className="flex items-center gap-2 w-full md:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[180px] border-gray-200 dark:border-gray-700 hover:border-blue-300 focus:border-blue-500 transition-colors" data-testid="select-category">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(c => (
                      <SelectItem key={c.categoryId} value={c.name}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid gap-4">
              {filteredResources.map((resource) => (
                <Card
                  key={resource.resourceId}
                  className="overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 border-0 group"
                  data-testid={`card-resource-${resource.resourceId}`}
                >
                  <div className="h-1 bg-gradient-to-r from-blue-500 to-cyan-500" />
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <CardTitle className="group-hover:text-blue-600 transition-colors text-lg" data-testid={`text-name-${resource.resourceId}`}>
                          {resource.name}
                        </CardTitle>
                        <div className="flex gap-2 mt-2 text-xs text-muted-foreground">
                          <span className="px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded">{resource.category}</span>
                          <Badge 
                            className={`font-semibold ${
                              resource.status === 'Available' ? 'bg-emerald-500 hover:bg-emerald-600 text-white' : 
                              resource.status === 'In Use' ? 'bg-blue-500 hover:bg-blue-600 text-white' : 'bg-red-500 hover:bg-red-600 text-white'
                            }`}
                            data-testid={`badge-status-${resource.resourceId}`}
                          >
                            {resource.status}
                          </Badge>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          setExpandedResource(
                            expandedResource === resource.resourceId ? null : resource.resourceId
                          )
                        }
                        className="hover:bg-blue-100 dark:hover:bg-blue-900"
                        data-testid={`button-details-${resource.resourceId}`}
                      >
                        {expandedResource === resource.resourceId ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </CardHeader>

                  {expandedResource === resource.resourceId && (
                    <CardContent className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/30">
                          <p className="text-xs text-muted-foreground">Total Quantity</p>
                          <p className="font-semibold text-lg" data-testid={`text-quantity-${resource.resourceId}`}>{resource.quantity}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/30">
                          <p className="text-xs text-muted-foreground">Available</p>
                          <p className="font-semibold text-lg" data-testid={`text-available-${resource.resourceId}`}>
                            {resource.quantity - (resource.allocatedQuantity || 0)}
                          </p>
                        </div>
                        <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/30">
                          <p className="text-xs text-muted-foreground">Allocated</p>
                          <p className="font-semibold text-lg" data-testid={`text-allocated-${resource.resourceId}`}>
                            {resource.allocatedQuantity || 0}
                          </p>
                        </div>
                        <div className="p-3 rounded-lg bg-cyan-50 dark:bg-cyan-900/30">
                          <p className="text-xs text-muted-foreground">Threshold</p>
                          <p className="font-semibold text-lg">{resource.thresholdLevel}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-900/30">
                          <p className="text-xs text-muted-foreground">Lab</p>
                          <p className="font-semibold" data-testid={`text-lab-${resource.resourceId}`}>{getLabName(resource.labId)}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-orange-50 dark:bg-orange-900/30">
                          <p className="text-xs text-muted-foreground">Warranty Expiry</p>
                          <p className="font-semibold text-sm">{new Date(resource.warrantyExpiry).toLocaleDateString()}</p>
                        </div>
                      </div>

                      {isAdmin && (
                        <div className="flex gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEdit(resource)}
                            className="flex-1 gap-1 hover:bg-blue-100 dark:hover:bg-blue-900 hover:text-blue-700 dark:hover:text-blue-300 hover:border-blue-400 transition-all duration-200"
                            data-testid={`button-edit-${resource.resourceId}`}
                          >
                            <Edit2 className="h-4 w-4" /> Edit
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDelete(resource.resourceId)}
                            className="flex-1 gap-1 text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900 hover:border-red-400 transition-all duration-200"
                            data-testid={`button-delete-${resource.resourceId}`}
                          >
                            <Trash2 className="h-4 w-4" /> Delete
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

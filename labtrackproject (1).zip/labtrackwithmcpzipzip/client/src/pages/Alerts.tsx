import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertCircle, CheckCircle2, Trash2, UserX, Package, Send, Copy, Check } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface Alert {
  alertId: number;
  alertType: string;
  message: string;
  severity: string;
  projectId?: string;
  resourceId?: number;
  createdOn: string;
  isResolved: boolean;
  sentToAgent?: boolean;
  resourceNeeded?: string;
  resourceType?: string;
}

interface AgentPayload {
  requests: {
    resource_needed: string;
    type: string;
    date: string;
  }[];
}

function extractResourceNeeded(alertType: string, message: string): { resourceNeeded: string; resourceType: string } | null {
  if (alertType === "Missing HR Resource" || alertType === "HR Already Allocated") {
    const roleMatch = message?.match(/role "([^"]+)"/);
    return {
      resourceNeeded: roleMatch ? roleMatch[1] : "Unknown Role",
      resourceType: "HR"
    };
  } else if (alertType === "Missing Resource" || alertType === "Insufficient Resource") {
    const resourceMatch = message?.match(/resource "([^"]+)"/i) || message?.match(/"([^"]+)"/);
    return {
      resourceNeeded: resourceMatch ? resourceMatch[1] : "Unknown Resource",
      resourceType: "Resource"
    };
  }
  return null;
}

function generateAgentPayload(resourceAlerts: Alert[]): AgentPayload {
  const requests = resourceAlerts.map(alert => {
    let resourceNeeded = "";
    let type = "";
    
    if (alert.alertType === "Missing HR Resource" || alert.alertType === "HR Already Allocated") {
      type = "HR";
      const roleMatch = alert.message?.match(/role "([^"]+)"/);
      resourceNeeded = roleMatch ? roleMatch[1] : "Unknown Role";
    } else {
      type = "Resource";
      const resourceMatch = alert.message?.match(/resource "([^"]+)"/i) || alert.message?.match(/"([^"]+)"/);
      resourceNeeded = resourceMatch ? resourceMatch[1] : "Unknown Resource";
    }
    
    return {
      resource_needed: resourceNeeded,
      type,
      date: alert.createdOn
    };
  });

  return {
    requests
  };
}

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filterResolved, setFilterResolved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showJsonDialog, setShowJsonDialog] = useState(false);
  const [jsonPayload, setJsonPayload] = useState<AgentPayload | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const fetchAlerts = async () => {
    try {
      const response = await fetch("/api/alerts");
      if (response.ok) {
        const data = await response.json();
        const processedAlerts = data.map((alert: Alert) => {
          const extracted = extractResourceNeeded(alert.alertType, alert.message);
          return {
            ...alert,
            resourceNeeded: extracted?.resourceNeeded,
            resourceType: extracted?.resourceType
          };
        });
        setAlerts(processedAlerts);
      }
    } catch (error) {
      console.error("Failed to fetch alerts:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const filtered = alerts.filter(a => {
    if (filterResolved) return a.isResolved === true;
    return a.isResolved === false;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-100 text-red-800";
      case "High": return "bg-orange-100 text-orange-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Low": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Missing HR Resource":
      case "HR Already Allocated":
        return "bg-purple-50 border-purple-200";
      case "Missing Resource":
      case "Insufficient Resource":
        return "bg-orange-50 border-orange-200";
      case "Project Timeline Expired":
        return "bg-blue-50 border-blue-200";
      case "Resource Fulfilled":
        return "bg-green-50 border-green-200";
      default: return "bg-gray-50 border-gray-200";
    }
  };

  const handleResolve = async (id: number) => {
    try {
      const response = await fetch(`/api/alerts/${id}/resolve`, { method: "POST" });
      if (response.ok) {
        setAlerts(alerts.map(a => a.alertId === id ? { ...a, isResolved: true } : a));
        toast({ title: "Alert resolved" });
      }
    } catch (error) {
      toast({ title: "Failed to resolve alert", variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const response = await fetch(`/api/alerts/${id}`, { method: "DELETE" });
      if (response.ok) {
        setAlerts(alerts.filter(a => a.alertId !== id));
        toast({ title: "Alert deleted" });
      }
    } catch (error) {
      toast({ title: "Failed to delete alert", variant: "destructive" });
    }
  };

  const handleShowJsonPreview = () => {
    const payload = generateAgentPayload(resourceAlerts);
    setJsonPayload(payload);
    setShowJsonDialog(true);
    setCopied(false);
  };

  const handleConfirmSendToAgent = async () => {
    try {
      const response = await fetch("/api/agent/send-resource-request", { method: "POST" });
      if (response.ok) {
        const data = await response.json();
        setJsonPayload(data);
        toast({ 
          title: "Sent to Agent", 
          description: `${data.requests?.length || 0} resource requests sent to external agent` 
        });
        fetchAlerts();
      }
    } catch (error) {
      toast({ title: "Failed to send to agent", variant: "destructive" });
    }
  };

  const handleCopyJson = () => {
    if (jsonPayload) {
      navigator.clipboard.writeText(JSON.stringify(jsonPayload, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "JSON copied to clipboard" });
    }
  };

  const resourceAlerts = alerts.filter(a => 
    !a.isResolved && 
    (a.alertType === "Missing HR Resource" || 
     a.alertType === "HR Already Allocated" ||
     a.alertType === "Missing Resource" ||
     a.alertType === "Insufficient Resource")
  );

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading alerts...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Alerts</h1>
            <p className="text-muted-foreground mt-1">Monitor system warnings and critical issues.</p>
          </div>
          {resourceAlerts.length > 0 && (
            <Button onClick={handleShowJsonPreview} className="gap-2">
              <Send className="h-4 w-4" />
              Send {resourceAlerts.length} to Agent
            </Button>
          )}
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{alerts.filter(a => !a.isResolved).length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">HR Needed</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-purple-600">
                {alerts.filter(a => !a.isResolved && (a.alertType === "Missing HR Resource" || a.alertType === "HR Already Allocated")).length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Resources Needed</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-orange-600">
                {alerts.filter(a => !a.isResolved && (a.alertType === "Missing Resource" || a.alertType === "Insufficient Resource")).length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Resolved</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{alerts.filter(a => a.isResolved).length}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilterResolved(false)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${!filterResolved ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                data-testid="button-active-alerts"
              >
                Active
              </button>
              <button
                onClick={() => setFilterResolved(true)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${filterResolved ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                data-testid="button-resolved-alerts"
              >
                Resolved
              </button>
            </div>
          </CardHeader>
          <CardContent>
            {filtered.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No {filterResolved ? "resolved" : "active"} alerts
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map(alert => (
                  <div key={alert.alertId} className={`p-4 border-l-4 rounded-lg ${getTypeIcon(alert.alertType)}`} data-testid={`card-alert-${alert.alertId}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          {alert.resourceType === "HR" ? (
                            <UserX className="h-4 w-4 text-purple-600" />
                          ) : alert.resourceType === "Resource" ? (
                            <Package className="h-4 w-4 text-orange-600" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-muted-foreground" />
                          )}
                          <h3 className="font-medium" data-testid={`text-title-${alert.alertId}`}>{alert.alertType}</h3>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{alert.message}</p>
                        
                        {alert.resourceNeeded && (
                          <div className="mt-2 p-2 bg-white/50 rounded border">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-medium text-muted-foreground">Resource Needed:</span>
                              <Badge variant="outline" className={alert.resourceType === "HR" ? "border-purple-300 text-purple-700" : "border-orange-300 text-orange-700"}>
                                {alert.resourceType === "HR" ? <UserX className="h-3 w-3 mr-1" /> : <Package className="h-3 w-3 mr-1" />}
                                {alert.resourceNeeded}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {alert.resourceType}
                              </Badge>
                            </div>
                          </div>
                        )}
                        
                        <div className="flex gap-2 mt-2 flex-wrap">
                          <Badge className={getSeverityColor(alert.severity)} data-testid={`badge-severity-${alert.alertId}`}>
                            {alert.severity}
                          </Badge>
                          {alert.projectId && (
                            <span className="text-xs text-muted-foreground bg-gray-100 px-2 py-0.5 rounded">
                              Project: {alert.projectId.substring(0, 15)}...
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground">
                            {alert.createdOn ? new Date(alert.createdOn).toLocaleString() : "N/A"}
                          </span>
                          {alert.sentToAgent && (
                            <Badge variant="outline" className="text-xs border-green-300 text-green-700">
                              Sent to Agent
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        {!alert.isResolved && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleResolve(alert.alertId)}
                            className="gap-2"
                            data-testid={`button-resolve-${alert.alertId}`}
                          >
                            <CheckCircle2 className="h-4 w-4" />
                          </Button>
                        )}
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDelete(alert.alertId)}
                          className="gap-2 text-destructive hover:text-destructive"
                          data-testid={`button-delete-${alert.alertId}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showJsonDialog} onOpenChange={setShowJsonDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>JSON Payload for Agent</DialogTitle>
            <DialogDescription>
              This is the JSON format that will be sent to the external agent for resource requests.
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-auto">
            <div className="relative">
              <Button 
                variant="outline" 
                size="sm" 
                className="absolute top-2 right-2 gap-1"
                onClick={handleCopyJson}
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied" : "Copy"}
              </Button>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-auto max-h-[50vh] font-mono">
                {jsonPayload ? JSON.stringify(jsonPayload, null, 2) : ""}
              </pre>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowJsonDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleConfirmSendToAgent} className="gap-2">
              <Send className="h-4 w-4" />
              Confirm & Send
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

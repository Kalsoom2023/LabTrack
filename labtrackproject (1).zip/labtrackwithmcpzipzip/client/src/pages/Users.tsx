import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Edit2, Trash2, X } from "lucide-react";
import { useState, useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/auth";

interface User {
  userId: number;
  name: string;
  email: string;
  role: string;
  username: string;
  isAllocated?: boolean;
  allocatedToProjectId?: string | null;
}

export default function Users() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    username: "",
    password: "",
    role: "Student",
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      setUsers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch users:", error);
      setUsers([]);
    }
  };

  const handleSubmit = async () => {
    try {
      const method = editingUser ? "PUT" : "POST";
      const url = editingUser ? `/api/users/${editingUser.userId}` : "/api/users";
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        fetchUsers();
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save user:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this user?")) return;
    
    try {
      const res = await fetch(`/api/users/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchUsers();
      }
    } catch (error) {
      console.error("Failed to delete user:", error);
    }
  };

  const handleEdit = (u: User) => {
    setEditingUser(u);
    setFormData({
      name: u.name,
      email: u.email,
      username: u.username,
      password: "",
      role: u.role,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingUser(null);
    setFormData({
      name: "",
      email: "",
      username: "",
      password: "",
      role: "Student",
    });
  };

  const filtered = Array.isArray(users) ? users.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "all" || u.role === roleFilter;
    return matchesSearch && matchesRole;
  }) : [];

  const isAdmin = currentUser?.role === "Administrator";

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Manager": return "bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300 border border-red-300 dark:border-red-700";
      case "Administrator": return "bg-purple-100 dark:bg-purple-900/40 text-purple-800 dark:text-purple-300 border border-purple-300 dark:border-purple-700";
      case "Technician": return "bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-blue-700";
      case "Assistant": return "bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300 border border-green-300 dark:border-green-700";
      default: return "bg-gray-100 dark:bg-gray-900/40 text-gray-800 dark:text-gray-300 border border-gray-300 dark:border-gray-700";
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">User Management</h1>
            <p className="text-muted-foreground mt-2">Manage user accounts and permissions across the system.</p>
          </div>
          {isAdmin && (
            <Button 
              className="gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white shadow-lg hover:shadow-xl transition-all duration-200" 
              onClick={() => { setShowForm(true); setEditingUser(null); }} 
              data-testid="button-create-user"
            >
              <Plus className="h-4 w-4" /> Add User
            </Button>
          )}
        </div>

        {showForm && (
          <Card className="shadow-lg border-2 border-indigo-500 bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950 dark:to-violet-950">
            <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-t-lg">
              <CardTitle>{editingUser ? "Edit User" : "Create New User"}</CardTitle>
              <Button variant="ghost" size="sm" onClick={resetForm} className="hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <Input
                placeholder="Full Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-name"
              />
              <Input
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-email"
              />
              <Input
                placeholder="Username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-username"
              />
              <Input
                type="password"
                placeholder="Password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors"
                data-testid="input-password"
              />
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                <SelectTrigger className="border-indigo-200 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors" data-testid="select-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Administrator">Administrator</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                  <SelectItem value="Technician">Technician</SelectItem>
                  <SelectItem value="Assistant">Assistant</SelectItem>
                  <SelectItem value="Student">Student/Faculty</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSubmit} className="flex-1 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white hover:shadow-lg transition-all duration-200" data-testid="button-save-user">
                  {editingUser ? "Update User" : "Create User"}
                </Button>
                <Button onClick={resetForm} variant="outline" className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" data-testid="button-cancel">Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-200 border border-gray-200 dark:border-gray-700">
          <CardHeader className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <Input
                type="text"
                placeholder="Search users by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 border-gray-200 dark:border-gray-700 focus:border-indigo-500 focus:ring-indigo-500 hover:border-indigo-300 transition-colors bg-gradient-to-r from-gray-50 to-indigo-50 dark:from-gray-900 dark:to-indigo-900"
                data-testid="input-search-users"
              />
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full md:w-48 border-gray-200 dark:border-gray-700 hover:border-indigo-300 focus:border-indigo-500 transition-colors" data-testid="select-role-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="Administrator">Administrator</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                  <SelectItem value="Technician">Technician</SelectItem>
                  <SelectItem value="Assistant">Assistant</SelectItem>
                  <SelectItem value="Student">Student/Faculty</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="rounded-lg border border-gray-200 dark:border-gray-700 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gradient-to-r from-gray-50 to-indigo-50 dark:from-gray-900 dark:to-indigo-900 border-b border-gray-200 dark:border-gray-700">
                  <tr>
                    <th className="p-4 text-left font-semibold text-gray-700 dark:text-gray-300">Name</th>
                    <th className="p-4 text-left font-semibold text-gray-700 dark:text-gray-300">Email</th>
                    <th className="p-4 text-left font-semibold text-gray-700 dark:text-gray-300">Role</th>
                    <th className="p-4 text-left font-semibold text-gray-700 dark:text-gray-300">Status</th>
                    {isAdmin && <th className="p-4 text-right font-semibold text-gray-700 dark:text-gray-300">Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((u, idx) => (
                    <tr key={u.userId} className={`border-b border-gray-200 dark:border-gray-700 hover:bg-indigo-50 dark:hover:bg-indigo-950 transition-colors duration-150 ${idx % 2 === 0 ? 'bg-white dark:bg-gray-950' : 'bg-gray-50 dark:bg-gray-900'}`} data-testid={`row-user-${u.userId}`}>
                      <td className="p-4 font-semibold text-gray-900 dark:text-gray-100" data-testid={`text-name-${u.userId}`}>{u.name}</td>
                      <td className="p-4 text-gray-700 dark:text-gray-300 text-sm">{u.email}</td>
                      <td className="p-4">
                        <Badge className={`font-semibold transition-all duration-200 hover:scale-105 ${getRoleColor(u.role)}`} data-testid={`badge-role-${u.userId}`}>
                          {u.role}
                        </Badge>
                      </td>
                      <td className="p-4">
                        {u.isAllocated && u.allocatedToProjectId ? (
                          <Badge className="bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700" data-testid={`badge-status-${u.userId}`}>
                            Assigned to Project
                          </Badge>
                        ) : (
                          <Badge className="bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700" data-testid={`badge-status-${u.userId}`}>
                            Available
                          </Badge>
                        )}
                      </td>
                      {isAdmin && (
                        <td className="p-4 text-right space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEdit(u)}
                            className="gap-1 hover:bg-indigo-100 dark:hover:bg-indigo-900 hover:text-indigo-700 dark:hover:text-indigo-300 hover:border-indigo-400 transition-all duration-200"
                            data-testid={`button-edit-user-${u.userId}`}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDelete(u.userId)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900 hover:border-red-400 transition-all duration-200"
                            data-testid={`button-delete-user-${u.userId}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

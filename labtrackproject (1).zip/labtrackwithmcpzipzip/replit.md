# LabTrack

## Overview
LabTrack is a laboratory resource management system built with React frontend and Express backend.

## Project Structure
```
├── client/              # React frontend
│   ├── public/          # Static assets
│   └── src/
│       ├── components/  # UI components (layout, ui)
│       ├── hooks/       # Custom React hooks
│       ├── lib/         # Utilities and helpers
│       └── pages/       # Page components
├── server/              # Express backend
│   ├── data/            # JSON data files
│   └── services/        # Backend services
├── shared/              # Shared types/schemas
└── package.json
```

## Tech Stack
- **Frontend**: React 19, Vite, TailwindCSS, Radix UI, Wouter (routing)
- **Backend**: Express
- **Data**: JSON files (stored in server/data/)

## Scripts
- `npm run dev` - Start development server (backend + frontend)
- `npm run build` - Build for production
- `npm start` - Run production build

## Key Features
- **Automatic Project Expiry**: Projects are checked every 60 seconds for expiration. When a project timeline ends, all resources and team members are automatically deallocated.
- **Automatic Report Generation**: When projects expire, completion reports are auto-generated with project details, allocated resources, team members, and deallocation summaries.
- **Lab Capacity Tracking**: Lab capacity is dynamically adjusted when team members are assigned or deallocated from projects.
- **Simplified Alert Payload**: Alerts sent to external agents contain only resource_needed, type, and date fields.

## API Endpoints
- `GET /api/reports` - Get all reports
- `GET /api/reports/:id` - Get a specific report
- `DELETE /api/reports/:id` - Delete a report
- `GET /api/mcp/check-expired` - Manually trigger expired project check
- `GET /api/agent/alerts` - Get simplified alerts for external agents

## Recent Changes
- December 12, 2025: Added automatic project expiry checker and report generation
- December 12, 2025: Replaced mock Reports data with real database-backed reports
- December 12, 2025: Reorganized project structure, removed nested folders and zip files

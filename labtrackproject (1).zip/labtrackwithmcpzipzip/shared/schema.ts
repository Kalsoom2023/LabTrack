import { pgTable, serial, varchar, integer, timestamp, boolean, time, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// USERS table
export const users = pgTable("users", {
  userId: serial("user_id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  role: varchar("role", { length: 50 }).notNull(),
  email: varchar("email", { length: 150 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ userId: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// LAB table
export const labs = pgTable("labs", {
  labId: serial("lab_id").primaryKey(),
  labName: varchar("lab_name", { length: 100 }).notNull(),
  location: varchar("location", { length: 255 }),
  inchargeName: varchar("incharge_name", { length: 100 }),
  labCapacity: integer("lab_capacity"),
  openTime: time("open_time"),
  closeTime: time("close_time"),
  maintenanceDay: varchar("maintenance_day", { length: 50 }),
});

export const insertLabSchema = createInsertSchema(labs).omit({ labId: true });
export type InsertLab = z.infer<typeof insertLabSchema>;
export type Lab = typeof labs.$inferSelect;

// RESOURCECATEGORY table
export const resourceCategories = pgTable("resource_categories", {
  categoryId: serial("category_id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: varchar("description", { length: 255 }),
});

export const insertResourceCategorySchema = createInsertSchema(resourceCategories).omit({ categoryId: true });
export type InsertResourceCategory = z.infer<typeof insertResourceCategorySchema>;
export type ResourceCategory = typeof resourceCategories.$inferSelect;

// RESOURCES table
export const resources = pgTable("resources", {
  resourceId: serial("resource_id").primaryKey(),
  labId: integer("lab_id").references(() => labs.labId),
  categoryId: integer("category_id").references(() => resourceCategories.categoryId),
  name: varchar("name", { length: 100 }).notNull(),
  category: varchar("category", { length: 100 }),
  quantity: integer("quantity").notNull().default(0),
  status: varchar("status", { length: 50 }).notNull().default('Available'),
  thresholdLevel: integer("threshold_level").default(5),
  warrantyExpiry: date("warranty_expiry"),
});

export const insertResourceSchema = createInsertSchema(resources).omit({ resourceId: true });
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

// ALERTS table
export const alerts = pgTable("alerts", {
  alertId: serial("alert_id").primaryKey(),
  resourceId: integer("resource_id").references(() => resources.resourceId),
  alertType: varchar("alert_type", { length: 100 }).notNull(),
  createdOn: timestamp("created_on").defaultNow(),
  resolvedOn: timestamp("resolved_on"),
  isResolved: boolean("is_resolved").notNull().default(false),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({ alertId: true, createdOn: true });
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;

// RESERVATIONS table
export const reservations = pgTable("reservations", {
  reservationId: serial("reservation_id").primaryKey(),
  resourceId: integer("resource_id").references(() => resources.resourceId),
  labId: integer("lab_id").references(() => labs.labId),
  userId: integer("user_id").references(() => users.userId),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  purpose: varchar("purpose", { length: 255 }),
  status: varchar("status", { length: 50 }).notNull().default('Pending'),
  approvedBy: integer("approved_by").references(() => users.userId),
});

export const insertReservationSchema = createInsertSchema(reservations).omit({ reservationId: true });
export type InsertReservation = z.infer<typeof insertReservationSchema>;
export type Reservation = typeof reservations.$inferSelect;

// PROJECTS table
export const projects = pgTable("projects", {
  projectId: serial("project_id").primaryKey(),
  title: varchar("title", { length: 100 }).notNull(),
  description: varchar("description", { length: 255 }),
  startDate: date("start_date"),
  endDate: date("end_date"),
  status: varchar("status", { length: 50 }).default('Ongoing'),
  labId: integer("lab_id").references(() => labs.labId),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ projectId: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// PROJECT_RESOURCES join table - assigns resources to projects
export const projectResources = pgTable("project_resources", {
  projectResourceId: serial("project_resource_id").primaryKey(),
  projectId: integer("project_id").references(() => projects.projectId),
  resourceId: integer("resource_id").references(() => resources.resourceId),
  allocatedQuantity: integer("allocated_quantity").notNull(),
});

export const insertProjectResourceSchema = createInsertSchema(projectResources).omit({ projectResourceId: true });
export type InsertProjectResource = z.infer<typeof insertProjectResourceSchema>;
export type ProjectResource = typeof projectResources.$inferSelect;

// USAGELOG table
export const usageLogs = pgTable("usage_logs", {
  usageId: serial("usage_id").primaryKey(),
  resourceId: integer("resource_id").references(() => resources.resourceId),
  userId: integer("user_id").references(() => users.userId),
  dateUsed: date("date_used"),
  quantityUsed: integer("quantity_used"),
  durationMinutes: integer("duration_minutes"),
  purpose: varchar("purpose", { length: 255 }),
});

export const insertUsageLogSchema = createInsertSchema(usageLogs).omit({ usageId: true });
export type InsertUsageLog = z.infer<typeof insertUsageLogSchema>;
export type UsageLog = typeof usageLogs.$inferSelect;
